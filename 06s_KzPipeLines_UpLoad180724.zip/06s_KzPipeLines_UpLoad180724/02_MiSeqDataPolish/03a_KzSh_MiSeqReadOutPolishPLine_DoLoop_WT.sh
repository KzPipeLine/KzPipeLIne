#!/bin/bash

#############################################
##
##  03a_KzSh_MiSeqReadOutPolishPLine_Test_3DoLoop_WT.sh
##
####  Run:  ###############
##
##  $ . 03a_KzSh_MiSeqReadOutPolishPLine_Test_3DoLoop_WT.sh
##
########################################
## Example_MiSeqData #################################
#
#Para_1:: 1,2,3,4,5
#Para_2:: R1, R2
#Para_3:: KO, WT
#
#Folder::  00a_KO-5_S5_L001_R1e2_001.fastq
#KO-1_S1_L001_R1_001.fastq
#KO-1_S1_L001_R2_001.fastq
#KO-2_S2_L001_R1_001.fastq
#KO-2_S2_L001_R2_001.fastq
#KO-3_S3_L001_R1_001.fastq
#KO-3_S3_L001_R2_001.fastq
#KO-4_S4_L001_R1_001.fastq
#KO-4_S4_L001_R2_001.fastq
#KO-5_S5_L001_R1_001.fastq
#KO-5_S5_L001_R2_001.fastq
#
#Folder::  00b_WT-5_S5_L001_R1e2_001.fastq
#WT-1_S6_L001_R1_001.fastq
#WT-1_S6_L001_R2_001.fastq
#WT-2_S7_L001_R1_001.fastq
#WT-2_S7_L001_R2_001.fastq
#WT-3_S8_L001_R1_001.fastq
#WT-3_S8_L001_R2_001.fastq
#WT-4_S9_L001_R1_001.fastq
#WT-4_S9_L001_R2_001.fastq
#WT-5_S10_L001_R1_001.fastq
#WT-5_S10_L001_R2_001.fastq
########################################

#!/bin/bash


## Start_line...........................

## Do_Loops ###### >> Done_Loops @ bottom below ##################

## (1) KO
#for Para_3 in KO    ## OR WT ???????????????????????????????????????????????
#do
#echo $Para_3
#
#for Para_2 in R1 R2
#do
#echo $Para_2
#
#for Para_1 in 1 2 3 4 5
#do
#echo $Para_1

# (2) WT           ## Change to InPutNames for WT !!!!!!!!!!!!!!!!!!!!!!!!
for Para_3 in WT
do
echo $Para_3

for Para_2 in R1 R2
do
echo $Para_2

for Para_1 in 1 2 3 4 5
do
echo $Para_1
echo $Para_1w

################################################



##################
## InPutNames!!!!!!!!!!!!!!!!!!!!!!
### KO
##[1] Name of the Project
#ProjectName="Kz160224_SLnMiSeq1"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "ProjectName::"
#echo -e $ProjectName
#
##[2] Name of 1st InPutFile
##InPutFile_1="KO-1_S1_L001_R1_001.fastq"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#InPutFile_1=$Para_3"-"$Para_1"_S"$Para_1"_L001_"$Para_2"_001.fastq"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "InPutFile_1::"
#echo -e $InPutFile_1
#
##[3] PreFix of Reads
##PreFixRead_1="Kz160224_SLnMiSeq1_KO1_R1_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#PreFixRead_1=$ProjectName"_"$InPutFile_1"_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "PreFixRead_1::"
#echo -e $PreFixRead_1
#
##[4] PreFix of OutPutFiles
##PreFixOut_1="Kz160224_SLnMiSeq1_KO1_R1"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#PreFixOut_1=$InPutFile_1"_Polished.fna"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "PreFixOut_1::"
#echo -e $PreFixOut_1

## WT
#[1] Name of the Project
ProjectName="Kz160225_SLnMiSeq1"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
echo -e  "ProjectName::"
echo -e $ProjectName

#[2] Name of 1st InPutFile
#InPutFile_1="KO-1_S1_L001_R1_001.fastq"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
Para_1w=`expr $Para_1 + 5`
InPutFile_1=$Para_3"-"$Para_1"_S"$Para_1w"_L001_"$Para_2"_001.fastq"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
echo -e  "InPutFile_1::"
echo -e $InPutFile_1

#[3] PreFix of Reads
#PreFixRead_1="Kz160224_SLnMiSeq1_KO1_R1_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
PreFixRead_1=$ProjectName"_"$InPutFile_1"_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
echo -e  "PreFixRead_1::"
echo -e $PreFixRead_1

#[4] PreFix of OutPutFiles
#PreFixOut_1="Kz160224_SLnMiSeq1_KO1_R1"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
PreFixOut_1=$InPutFile_1"_Polished"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
echo -e  "PreFixOut_1::"
echo -e $PreFixOut_1



############################
## Making2ndNames!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#[1] BigLogName
BigLogName=$ProjectName"_BigLog.txt"
echo -e  "BigLogName::"
echo -e $BigLogName

#[2] OutFileName_Renamed
OutFileRen=$PreFixOut_1"_Ren"
echo -e "## OutFileRenamed:: "$OutFileRen 2>&1 | tee -a  ../$BigLogName

#[3] OutFileName_Renamed > QualityTrimmed
OutFileRenTrm=$PreFixOut_1"_RenTrm"
echo -e "## OutFileRenamedTrimmed:: "$OutFileRenTrm 2>&1 | tee -a  ../$BigLogName

#[4] OutFileName_RenamedTrimmed > QualtyFiltered
OutFileRenTrmQfl=$PreFixOut_1"_RenTrmQfl"
echo -e "## OutFileRenamedTrimmedQFiltered:: "$OutFileRenTrmQfl 2>&1 | tee -a  ../$BigLogName

#[5] OutFileName_RenamedTrimmedQFiltered > ReverseComplement
OutFileRenTrmQflRcp=$PreFixOut_1"_RenTrmQflRcp"
echo -e "## OutFileRenamedTrimmedQFilteredRComplement:: "$OutFileRenTrmQflRcp 2>&1 | tee -a  ../$BigLogName

#[6] OutFileName_RenamedTrimmedQFilteredRComplement > fasta
OutFileRenTrmQflRcpFna=$PreFixOut_1"_RenTrmQflRcp.fna"
echo -e "## OutFileRenamedTrimmedQFilteredRComplementFastaNA:: "$OutFileRenTrmQflRcpFna 2>&1 | tee -a  ../$BigLogName






##################################
## Here Starts!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

echo -e "\n## "$ProjectName"_Started........." | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName



## 1: Rename reads
echo -e "\n## 1: Rename reads" | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName
echo -e "## InPutFile_1:: "$InPutFile_1 | tee -a  ../$BigLogName
echo -e "## PreFixRead_1:: "$PreFixRead_1 | tee -a  ../$BigLogName

perl ~/KzPerls/KzFastqRenamerArgv_2AtResitant_160224.pl $PreFixRead_1 $InPutFile_1 $OutFileRen 2>&1 | tee -a ../$BigLogName




##2: FASTQ Quality Trimmer
echo -e "\n## 2: FASTQ Quality Trimmer" | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName
echo -e "## InPutFile:: "$OutFileRen | tee -a  ../$BigLogName
echo -e "## OutPutFile:: "$OutFileRenTrm | tee -a  ../$BigLogName

fastq_quality_trimmer -v -t 20 -l 200 -i $OutFileRen -o $OutFileRenTrm 2>&1 | tee -a ../$BigLogName




##3: FASTQ Quality Filter

echo -e "\n## 3: FASTQ Quality Filter" | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName
echo -e "## InPutFile:: "$$OutFileRenTrm | tee -a  ../$BigLogName
echo -e "## OutPutFile:: "$OutFileRenTrmQfl | tee -a  ../$BigLogName

fastq_quality_filter -v -q 20 -p 80 -i $OutFileRenTrm -o $OutFileRenTrmQfl 2>&1 | tee -a ../$BigLogName




##4: FASTQ/A Reverse Complement
echo -e "\n## 4: FASTQ/A Reverse Complement" | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName
echo -e "## InPutFile:: "$OutFileRenTrmQfl | tee -a  ../$BigLogName
echo -e "## OutPutFile:: "$OutFileRenTrmQflRcp | tee -a  ../$BigLogName

fastx_reverse_complement -v -i $OutFileRenTrmQfl -o $OutFileRenTrmQflRcp 2>&1 | tee -a ../$BigLogName




##5: FASTQ-to-FASTA
echo -e "\n## 5: FASTQ-to-FASTA" | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName
echo -e "## InPutFile:: "$OutFileRenTrmQflRcp | tee -a  ../$BigLogName
echo -e "## OutPutFile:: "$OutFileRenTrmQflRcpFna | tee -a  ../$BigLogName


fastq_to_fasta -v -n -i $OutFileRenTrmQflRcp -o $OutFileRenTrmQflRcpFna 2>&1 | tee -a ../$BigLogName

echo -e '\a'        #Beep

## Done_Loop #################################


done        #for Para_1
done        #for Para_2
done        #for Para_3

##################

echo -e '\a'        #Beep
echo -e '\a'        #Beep
echo -e '\a'        #Beep

## All Done ######################################
















