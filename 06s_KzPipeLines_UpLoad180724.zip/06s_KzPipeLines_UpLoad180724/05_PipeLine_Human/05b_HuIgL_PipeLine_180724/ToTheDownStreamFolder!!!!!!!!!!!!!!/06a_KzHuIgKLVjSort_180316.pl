#!/usr/bin/perl -w

###########################################################
#   KzHuIgKLVjSort_180316.pl
#
##  Run:  ##################################################
#
#   perl KzHuIgKLVjSort_180316.pl InPutFile OutPutFile
#
#   Ex. 180317
#   perl KzHuIgKLVjSort_180316.pl TestOutF_IgBlastExcel_KLMerged.txt_mfasta.txt TestOutF_1803171.txt
#
##########################
#
#       The derivative of KzVdjSort.pl
#       This is for the assignment of specific gene_number for IGKV and IGKJ, >> And for IGLV and IGLJ
#
#			reading the OUTPUT of "KzMFImgtTabF_ProdFasta.pl ( not from KzMFImgtTabF_ProdExcel.pl" )
#           of IgK_Analysis, ex Kz131011_IgK_test.txt
#		The OUTPUT subfile:
#			>$Sequence_ID, "\t",$V_GeneTop, "\t",$D_GENE_and_allele, "\t",$J_GeneTop
#			$V_GENE,"\t",$D_GENE,"\t",$J_GENE
#
#		##IgK > $V_GENE: 101 + 1 (0 - 100, 999)	$J_GENE: 4 + 1  (0 - 3, 999) >> ND: 101, 4
#       IgKL > $V_GENE: 101 + 3 + 1 (0 - 103, 999)	$J_GENE: 4 + 3 + 1  (0 - 6, 999) >> ND: 104, 7
#
#
#
#       ###########################################
#
#
#       Ver7:   160308      For MiSeq_PipeLine
#
#		Ver.1: 130510
#		Ver.2: 130516		> $vtarget definition, before "_01"
#							> $nd: Not Defined
#       Ver.3: 130801       > 12 Dh Genes for Major IMGT-assignment
#       130813 > FrmMF
#       131011 > For IgK chain
#
#       Ver4: 140218     IGKV, IGKJ genes as on chromosome order
#       Ver5: 140815    IgK and IgL for 1in20IgL
#       Ver6: 140828    Add "IGKV14_126" and remove "IGKV1_35"
#
#######################################################################################

use strict;
use warnings;


# !! The Numbers starts with 0 as it is perl !!
# The input is the OUTPUT of "KzMFImgtTabF_ProdExcel.pl"



my (@IgKLV, @IgKLJ);
my ($v, $d, $j);
my $i = 0;
my $ii = 0;
my $vl = 0;
my $ndv = 0;
my $ndd = 0;
my $ndj = 0;
# my $dl = 0;
# my $jl = 0;



my ($output);
my ($output1);
my ($prod);
my ($seqid);
my ($read);

#my ($Sequence_ID);
#my ($V_GENE_and_allele);
#my ($D_GENE_and_allele);
#my ($J_GENE_and_allele);
#my ($AA_JUNCTION);
#my ($Sequence);
#my ($Seqid,$V_GENE_and_allele,$V_REGION_identity_pc,$J_GENE_and_allele,$D_GENE_and_allele,$CDR_IMGT_lengths,$AA_JUNCTION,$LongestLength,$ItsFrame);  # Kz140814_KnIgKEt1in20IgL_Mftla.txtのInput用
my ($Sequence_ID, $V_GeneTop, $J_GeneTop, $Chain_type, $Stop_codon, $VJ_frame, $Productive, $Strand);  # For IgBlast_OutPut

my ($vtarget);
my ($dtarget);
my ($jtarget);

my ($V_GENE,$D_GENE,$J_GENE);

my (@VdjMtx1, @VdjMtx2);

my ($search01);



# -----------------------

# @IghV = ("IGHV1_4","IGHV1_5","IGHV1_7","IGHV1_9","IGHV1_11","IGHV1_12","IGHV1_14","IGHV1_15","IGHV1_16","IGHV1_17_1","IGHV1_18","IGHV1_19","IGHV1_20","IGHV1_22","IGHV1_23","IGHV1_26","IGHV1_31","IGHV1_34","IGHV1_36","IGHV1_37","IGHV1_39","IGHV1_42","IGHV1_43","IGHV1_47","IGHV1_49","IGHV1_50","IGHV1_52","IGHV1_53","IGHV1_54","IGHV1_55","IGHV1_56","IGHV1_58","IGHV1_59","IGHV1_61","IGHV1_62_1","IGHV1_62_2","IGHV1_62_3","IGHV1_63","IGHV1_64","IGHV1_66","IGHV1_67","IGHV1_69","IGHV1_71","IGHV1_72","IGHV1_74","IGHV1_75","IGHV1_76","IGHV1_77","IGHV1_78","IGHV1_80","IGHV1_81","IGHV1_82","IGHV1_84","IGHV1_85","IGHV2_2","IGHV2_3","IGHV2_4","IGHV2_5","IGHV2_6","IGHV2_7","IGHV2_9","IGHV3_1","IGHV3_3","IGHV3_4","IGHV3_5","IGHV3_6","IGHV3_8","IGHV4_1","IGHV5_2","IGHV5_4","IGHV5_6","IGHV5_9","IGHV5_12","IGHV5_15","IGHV5_16","IGHV5_17","IGHV6_3","IGHV6_4","IGHV6_5","IGHV6_6","IGHV6_7","IGHV7_2","IGHV7_3","IGHV7_4","IGHV8_2","IGHV8_4","IGHV8_5","IGHV8_6","IGHV8_8","IGHV8_9","IGHV8_11","IGHV8_12","IGHV8_13","IGHV9_1","IGHV9_2","IGHV9_3","IGHV9_4","IGHV10_1","IGHV10_3","IGHV11_1","IGHV11_2","IGHV12_3","IGHV13_1","IGHV13_2","IGHV14_1","IGHV14_2","IGHV14_3","IGHV14_4","IGHV15_2","IGHV16_1","ND");

#@IgKV = ("IGKV1_88","IGKV1_110","IGKV1_122","IGKV1_131","IGKV1_132","IGKV1_133","IGKV1_135","IGKV1_136","IGKV2_95_1","IGKV2_95_2","IGKV2_113","IGKV2_116","IGKV3_4","IGKV3_6","IGKV3_8","IGKV3_9","IGKV3_11","IGKV4_50","IGKV4_52","IGKV4_53","IGKV4_54","IGKV4_55","IGKV4_56","IGKV4_57","IGKV4_58","IGKV4_59","IGKV4_60","IGKV4_61","IGKV4_62","IGKV4_63","IGKV4_65","IGKV4_68","IGKV4_69","IGKV4_70","IGKV4_71","IGKV4_72","IGKV4_73","IGKV4_74","IGKV4_75","IGKV4_77","IGKV4_78","IGKV4_79","IGKV4_80","IGKV4_81","IGKV4_83","IGKV4_86","IGKV4_90","IGKV4_91","IGKV4_92","IGKV5_37","IGKV5_39","IGKV5_40_1","IGKV5_45","IGKV5_48","IGKV6_14","IGKV6_15","IGKV6_17","IGKV6_20","IGKV6_23","IGKV6_25","IGKV6_29","IGKV6_32","IGKV7_33","IGKV8_16","IGKV8_18","IGKV8_19","IGKV8_21","IGKV8_22","IGKV8_24","IGKV8_26","IGKV8_27","IGKV8_28","IGKV9_119","IGKV9_120","IGKV10_95","IGKV12_38","IGKV12_40","IGKV12_41","IGKV12_46","IGKV12_47","IGKV12_49","IGKV12_66","IGKV12_67","IGKV12_89","IGKV13_54_1","IGKV13_55_1","IGKV13_56_1","IGKV13_57_1","IGKV13_61_1","IGKV13_62_1","IGKV13_64","IGKV13_71_1","IGKV13_73_1","IGKV13_74_1","IGKV13_76","IGKV13_78_1","IGKV13_80_1","IGKV13_82","IGKV13_84","IGKV13_85","IGKV13_87","IGKV13_89_1","IGKV14_111","IGKV14_118_1","IGKV14_118_2","IGKV14_126","IGKV14_126_1","IGKV14_130","IGKV17_121","IGKV17_127","IGKV17_134","IGKV19_93","999");
#@IgKV = ("IGKV2_137","IGKV1_135","IGKV1_133","IGKV1_132","IGKV1_131","IGKV14_130","IGKV9_129","IGKV17_127","IGKV11_125","IGKV9_124","IGKV9_123","IGKV1_122","IGKV17_121","IGKV9_120","IGKV1_117","IGKV2_112","IGKV14_111","IGKV1_110","IGKV2_109","IGKV16_104","IGKV15_103","IGKV20_101_2","IGKV14_100","IGKV1_99","IGKV12_98","IGKV10_96","IGKV10_95","IGKV10_94","IGKV19_93","IGKV4_92","IGKV4_91","IGKV4_90","IGKV12_89","IGKV1_88","IGKV4_86","IGKV13_85","IGKV13_84","IGKV4_81","IGKV4_80","IGKV4_79","IGKV4_78","IGKV4_74","IGKV4_73","IGKV4_72","IGKV4_71","IGKV4_70","IGKV4_69","IGKV4_68","IGKV4_63","IGKV4_62","IGKV4_61","IGKV4_59","IGKV4_58","IGKV4_57_1","IGKV4_57","IGKV4_55","IGKV4_54","IGKV4_53","IGKV4_51","IGKV4_50","IGKV5_48","IGKV12_46","IGKV5_45","IGKV12_44","IGKV5_43","IGKV12_41","IGKV5_39","IGKV12_38","IGKV5_37","IGKV18_36","IGKV1_35","IGKV8_34","IGKV7_33","IGKV6_32","IGKV8_30","IGKV6_29","IGKV8_28","IGKV8_27","IGKV8_26","IGKV6_25","IGKV8_24","IGKV8_23_1","IGKV6_23","IGKV8_21","IGKV6_20","IGKV8_19","IGKV8_18","IGKV6_17","IGKV8_16","IGKV6_15","IGKV6_14","IGKV6_13","IGKV3_12","IGKV3_10","IGKV3_9","IGKV3_7","IGKV3_5","IGKV3_4","IGKV3_3","IGKV3_2","IGKV3_1","999");

#@IgKLV = ("IGKV2_137","IGKV1_135","IGKV1_133","IGKV1_132","IGKV1_131","IGKV14_130","IGKV9_129","IGKV17_127","IGKV11_125","IGKV9_124","IGKV9_123","IGKV1_122","IGKV17_121","IGKV9_120","IGKV1_117","IGKV2_112","IGKV14_111","IGKV1_110","IGKV2_109","IGKV16_104","IGKV15_103","IGKV20_101_2","IGKV14_100","IGKV14_126","IGKV1_99","IGKV12_98","IGKV10_96","IGKV10_95","IGKV10_94","IGKV19_93","IGKV4_92","IGKV4_91","IGKV4_90","IGKV12_89","IGKV1_88","IGKV4_86","IGKV13_85","IGKV13_84","IGKV4_81","IGKV4_80","IGKV4_79","IGKV4_78","IGKV4_74","IGKV4_73","IGKV4_72","IGKV4_71","IGKV4_70","IGKV4_69","IGKV4_68","IGKV4_63","IGKV4_62","IGKV4_61","IGKV4_59","IGKV4_58","IGKV4_57_1","IGKV4_57","IGKV4_55","IGKV4_54","IGKV4_53","IGKV4_51","IGKV4_50","IGKV5_48","IGKV12_46","IGKV5_45","IGKV12_44","IGKV5_43","IGKV12_41","IGKV5_39","IGKV12_38","IGKV5_37","IGKV18_36","IGKV8_34","IGKV7_33","IGKV6_32","IGKV8_30","IGKV6_29","IGKV8_28","IGKV8_27","IGKV8_26","IGKV6_25","IGKV8_24","IGKV8_23_1","IGKV6_23","IGKV8_21","IGKV6_20","IGKV8_19","IGKV8_18","IGKV6_17","IGKV8_16","IGKV6_15","IGKV6_14","IGKV6_13","IGKV3_12","IGKV3_10","IGKV3_9","IGKV3_7","IGKV3_5","IGKV3_4","IGKV3_3","IGKV3_2","IGKV3_1","IGLV2","IGLV3","IGLV1","999");

# Human
@IgKLV = ("IGKV1_5", "IGKV1_6", "IGKV1_8", "IGKV1_9", "IGKV1_12", "IGKV1_13", "IGKV1_16", "IGKV1_17", "IGKV1_27", "IGKV1_33", "IGKV1_39", "IGKV1D_8", "IGKV1D_12", "IGKV1D_13", "IGKV1D_16", "IGKV1D_17", "IGKV1D_33", "IGKV1D_39", "IGKV1D_43", "IGKV1_NL1", "IGKV2_24", "IGKV2_28", "IGKV2_29", "IGKV2_30", "IGKV2_40", "IGKV2D_26", "IGKV2D_28", "IGKV2D_29", "IGKV2D_30", "IGKV2D_40", "IGKV3_11", "IGKV3_15", "IGKV3_20", "IGKV3D_7", "IGKV3D_11", "IGKV3D_15", "IGKV3D_20", "IGKV4_1", "IGKV5_2", "IGKV6_21", "IGKV6D_21", "IGLV1_36", "IGLV1_40", "IGLV1_44", "IGLV1_47", "IGLV1_51", "IGLV2_8", "IGLV2_11", "IGLV2_14", "IGLV2_18", "IGLV2_23", "IGLV3_1", "IGLV3_9", "IGLV3_10", "IGLV3_16", "IGLV3_19", "IGLV3_21", "IGLV3_22", "IGLV3_25", "IGLV3_27", "IGLV4_3", "IGLV4_60", "IGLV4_69", "IGLV5_37", "IGLV5_39", "IGLV5_45", "IGLV5_52", "IGLV6_57", "IGLV7_43", "IGLV7_46", "IGLV8_61", "IGLV9_49", "IGLV10_54", "999");



# @IghD = ("IGHD1_1","IGHD1_2","IGHD1_3","IGHD2_1","IGHD2_2","IGHD2_3","IGHD2_4","IGHD2_5","IGHD3_1","IGHD3_2","IGHD3_3","IGHD4_1");

# @IghJ = ("IGHJ1","IGHJ2","IGHJ3","IGHJ4");

#@IgKJ = ("IGKJ1","IGKJ2","IGKJ3","IGKJ4","IGKJ5","999");
#@IgKJ = ("IGKJ1","IGKJ2","IGKJ4","IGKJ5","999");
#@IgKLJ = ("IGKJ1","IGKJ2","IGKJ4","IGKJ5","IGLJ2","IGLJ3","IGLJ1","999");

# Human
@IgKLJ = ("IGKJ1", "IGKJ2", "IGKJ3", "IGKJ4", "IGKJ5", "IGLJ1", "IGLJ2", "IGLJ3", "IGLJ6", "IGLJ7", "999");

# ---------------------


#print " Output file name? ", "\n";
#chomp ( $output = <STDIN>  );
$output=$ARGV[1];
chomp ($output);
open ( SUBFILE1, ">>$output" ) or die "Cannnot open SubSeq.fa", "\n";


###  LogFile  ###########################
#
##my ($DataNameId);
#my ($output0);
#my ($now);
#
#use POSIX 'strftime';
#
#$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
#print "\n",">> Started: $now", "\n";
#
#
### LogFileを開く
#$output1 = $output."_Log.txt";                                       # Set the name of Log_File: $output1
#open ( SUBFILE0, ">>$output1" ) or die "Cannnot open SubSeq.fa", "\n";      # Open the Log_File
#
#print SUBFILE0 "\n", "##  ", $output1, "  ## ";
#print SUBFILE0 "\n", "! Started:: $now","\n";
#
###########################


## DATAFILEの限定；この操作をしないと、prescript.shのもとでは、ARGV[1],ARGV[2]も読み込んでしまう。
my $InPutFile2 = $ARGV[0];
open(DATAFILE2, "< $InPutFile2") or die("error :$!");


$read = 0;

while (<DATAFILE2>)  {                   ## DATAFILEの限定
    
    ##
    chomp ($_);
    $_ =~ tr/-*/__/;        # *01などの前処理
    #	print "\n", $_, "\n";
    
    
    ##
    if ( $_ =~ /^>/ ) {				# IF it is comment line

	
        $read++;
        
        $seqid=$_;
        
        next;
        
    } else {
	
        $V_GENE = "";
        $D_GENE = "";
        $J_GENE = "";
	
	
        ($V_GeneTop, $J_GeneTop, $Chain_type, $Stop_codon, $VJ_frame, $Productive, $Strand) = split(/\t/,$_);

        $vl = 0;
        $vtarget = "";	
        $ii = 0;

 
        # Moseの場合、B6のalleleは"_01"だったので考慮したが、Humanの場合には、"_01"の他に様々なalleleがある！！
        $vtarget = substr($V_GeneTop, 0, -3);      #3番目の引数には文字の長さを指定します。文字の長さを省略した場合には最後の文字までとなります。また負の値を指定した場合には最後の文字を「-1」として先頭に向かって指定した長さだけ戻った位置にある文字の前の文字までとなります。
#        #	Find the "_01" in $V_GeneTop
#        $search01 = substr($V_GeneTop,-3);
#        #print "\n","Search01= ",$search01," \n";		# print the length to _01
#        
#            if ($search01 eq "_01")  {
#                #			print "\n","ii = ","$ii","\n";		# print the length to _01
#                $vtarget = substr($V_GeneTop, 0, -3);      #3番目の引数には文字の長さを指定します。文字の長さを省略した場合には最後の文字までとなります。また負の値を指定した場合には最後の文字を「-1」として先頭に向かって指定した長さだけ戻った位置にある文字の前の文字までとなります。
#                print "\n","vtarget = ","$vtarget","\n";		# print the $vtarget
#            }
        
        

	
	
	
        # Find IgKV_gene Number : $v
        #$V_GENE = 104;          # Mouseは"999"を除いて、104個のIgKLV
        $V_GENE = 73;          # Humanは"999"を除いて、73個のIgKLV
        for $v (0..$#IgKLV) {
		
            # $vl = length($IghV[$v]);							# Here Problem!!! >> Look "_01" 
            # $vtarget = substr($V_GeneTop, 0, $vl);		# Here Problem!!! >> Look "_01" 
		
		
            #		print "\n","IghV:", $IghV[$v];
            #		print "\n","vtarget: ", $vtarget,"\n";	
		

            if ($vtarget eq $IgKLV[$v]){
                #	print "\n"," Hit!!! ", $IghV[$v]," Hit_$v ", $v ;
                $V_GENE = $v;
                last;
            } 
        }
		
        #if ($V_GENE eq 104){        # Mouseは"999"を除いて、104個のIgKLV
        if ($V_GENE eq 73){        # Humanは"999"を除いて、73個のIgKLV
            $ndv++;	
        }
	
        # Find IghD_gene Number : $d	
        #        $D_GENE = "ND";
#        for $d (0..$#IghD) {
#
#            $dtarget = "";
#
#            if ($D_GENE_and_allele eq ""){
#                last;
#            }
#
#            $dtarget = substr($D_GENE_and_allele,7);
#            #	print "\n","dtarget: ", $dtarget;
#            if (substr($dtarget,0,7) eq $IghD[$d]){
#                #	print "\n"," Hit!!! ", $IghD[$d]," Hit_$d ", $d ;
#                $D_GENE = $d;
#                last;
#            }
#        }
#
#        if ($D_GENE eq "ND"){
#                $ndd++;
#        }
        
        
        
        #	Find the "_01" in $J_GeneTop
        $search01 = substr($J_GeneTop,-3);
        #print "\n","Search01= ",$search01," \n";		# print the length to _01
 
        # Moseの場合、B6のalleleは"_01"だったので考慮したが、Humanの場合には、"_01"の他に様々なalleleがある！！
        $jtarget = substr($J_GeneTop, 0, -3);      #3番目の引数には文字の長さを指定します。文字の長さを省略した場合には最後の文字までとなります。また負の値を指定した場合には最後の文字を「-1」として先頭に向かって指定した長さだけ戻った位置にある文字の前の文字までとなります。
#        if ($search01 eq "_01")  {
#            #			print "\n","ii = ","$ii","\n";		# print the length to _01
#            $jtarget = substr($J_GeneTop, 0, -3);      #3番目の引数には文字の長さを指定します。文字の長さを省略した場合には最後の文字までとなります。また負の値を指定した場合には最後の文字を「-1」として先頭に向かって指定した長さだけ戻った位置にある文字の前の文字までとなります。
#            #print "\n","jtarget = ","$jtarget","\n";		# print the $vtarget
#        }
 
        
        ## Find IgKJ_gene Number : $j
#        $J_GENE = 7;
        $J_GENE = 10;       # Humanの場合は10
        for $j (0..$#IgKLJ) {

            if ($jtarget eq $IgKLJ[$j]){
                #	print "\n"," Hit!!! ", $IghJ[$j]," Hit_$j ", $j ;
                $J_GENE = $j;
                last;
            }
        }
        
        ##
#        if ($J_GENE eq 7){
        if ($J_GENE eq 10){     # Humanの場合は10
                $ndj++;
        }
        
        
		
        #            print ">", $seqid, "\t",$V_GeneTop, "\t",$D_GENE_and_allele, "\t",$J_GeneTop,"\n";
            print $seqid, "\t",$V_GeneTop, "\t",$J_GeneTop,"\n";
        #            print $V_GENE,"\t",$D_GENE,"\t",$J_GENE,"\n";
            print $V_GENE,"\t",$J_GENE,"\n";
        
        #            print SUBFILE1 ">", $seqid, "\t",$V_GeneTop, "\t",$D_GENE_and_allele, "\t",$J_GeneTop,"\n";
            print SUBFILE1 $seqid, "\t",$V_GeneTop, "\t",$J_GeneTop,"\n";
        #            print SUBFILE1 $V_GENE,"\t",$D_GENE,"\t",$J_GENE,"\n";
            print SUBFILE1 $V_GENE,"\t",$J_GENE,"\n";
	
    }     
}

close (SUBFILE1);

print "\n", " -- Done -- ", " [ ",$read," Sequences Try Assigned, ND: V=",$ndv," D=",$ndd," J=", $ndj," ]","\n";

####  Log( )  ###
#$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
#print "\n"," -- Done::",$now,"\n";
#print SUBFILE0 "\n"," -- Done::",$now,"\n";
#
#print "\n"," -- Done: KzIgKLVjSort_140815.pl -- ","\n"," [ ",$read," Sequences Try Assigned, ND: V=",$ndv," D=",$ndd," J=", $ndj," ]","\n";
#print SUBFILE0 "\n"," -- Done: KzIgKLVjSort_140815.pl -- ","\n", " [ ",$read," Sequences Try Assigned, ND: V=",$ndv," D=",$ndd," J=", $ndj," ]","\n";
#
#close (SUBFILE0);
#
####

print "\007";
#print "\007";
#print "\007";

# End

