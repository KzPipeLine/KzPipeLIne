##################
#  07_KzR_HuIgKLMatrix180317.R
#
#  ## InPut: ########################
#
#   > Data1 <- read.table("TestOutF_1803171_RmCmLn.txt")
#   > DataName <- "KzR180317"
#   > source("07_KzR_HuIgKLMatrix180317.R")
#
######################################################
#
#   Ver2    140815  For IgK and IgL
#   Ver3    140828  Add "IGKV14_126" and remove "IGKV1_35"
#
###################################


##  "KzR_MatrixData1ToVDJ1_130814.R"  ###########

VJKL <- array(0, dim = c(74,11))

cat(length(Data1$V1),"\n")

VV <- 0
JJ <- 0

for (i2 in 1:length(Data1$V1)){

    VV <- Data1[i2,1]
    JJ <- Data1[i2,2]
    
    VV <- VV + 1
    JJ <- JJ + 1
    
    
cat(VV,JJ,"\n")

    VJKL[VV,JJ] <- VJKL[VV,JJ] + 1
    
}

#IgVKL <- c("IGKV2_137","IGKV1_135","IGKV1_133","IGKV1_132","IGKV1_131","IGKV14_130","IGKV9_129","IGKV17_127","IGKV11_125","IGKV9_124","IGKV9_123","IGKV1_122","IGKV17_121","IGKV9_120","IGKV1_117","IGKV2_112","IGKV14_111","IGKV1_110","IGKV2_109","IGKV16_104","IGKV15_103","IGKV20_101_2","IGKV14_100","IGKV1_99","IGKV12_98","IGKV10_96","IGKV10_95","IGKV10_94","IGKV19_93","IGKV4_92","IGKV4_91","IGKV4_90","IGKV12_89","IGKV1_88","IGKV4_86","IGKV13_85","IGKV13_84","IGKV4_81","IGKV4_80","IGKV4_79","IGKV4_78","IGKV4_74","IGKV4_73","IGKV4_72","IGKV4_71","IGKV4_70","IGKV4_69","IGKV4_68","IGKV4_63","IGKV4_62","IGKV4_61","IGKV4_59","IGKV4_58","IGKV4_57_1","IGKV4_57","IGKV4_55","IGKV4_54","IGKV4_53","IGKV4_51","IGKV4_50","IGKV5_48","IGKV12_46","IGKV5_45","IGKV12_44","IGKV5_43","IGKV12_41","IGKV5_39","IGKV12_38","IGKV5_37","IGKV18_36","IGKV1_35","IGKV8_34","IGKV7_33","IGKV6_32","IGKV8_30","IGKV6_29","IGKV8_28","IGKV8_27","IGKV8_26","IGKV6_25","IGKV8_24","IGKV8_23_1","IGKV6_23","IGKV8_21","IGKV6_20","IGKV8_19","IGKV8_18","IGKV6_17","IGKV8_16","IGKV6_15","IGKV6_14","IGKV6_13","IGKV3_12","IGKV3_10","IGKV3_9","IGKV3_7","IGKV3_5","IGKV3_4","IGKV3_3","IGKV3_2","IGKV3_1","IGLV2","IGLV3","IGLV1","999")
#IgVKL <- c("IGKV2_137","IGKV1_135","IGKV1_133","IGKV1_132","IGKV1_131","IGKV14_130","IGKV9_129","IGKV17_127","IGKV11_125","IGKV9_124","IGKV9_123","IGKV1_122","IGKV17_121","IGKV9_120","IGKV1_117","IGKV2_112","IGKV14_111","IGKV1_110","IGKV2_109","IGKV16_104","IGKV15_103","IGKV20_101_2","IGKV14_100","IGKV14_126","IGKV1_99","IGKV12_98","IGKV10_96","IGKV10_95","IGKV10_94","IGKV19_93","IGKV4_92","IGKV4_91","IGKV4_90","IGKV12_89","IGKV1_88","IGKV4_86","IGKV13_85","IGKV13_84","IGKV4_81","IGKV4_80","IGKV4_79","IGKV4_78","IGKV4_74","IGKV4_73","IGKV4_72","IGKV4_71","IGKV4_70","IGKV4_69","IGKV4_68","IGKV4_63","IGKV4_62","IGKV4_61","IGKV4_59","IGKV4_58","IGKV4_57_1","IGKV4_57","IGKV4_55","IGKV4_54","IGKV4_53","IGKV4_51","IGKV4_50","IGKV5_48","IGKV12_46","IGKV5_45","IGKV12_44","IGKV5_43","IGKV12_41","IGKV5_39","IGKV12_38","IGKV5_37","IGKV18_36","IGKV8_34","IGKV7_33","IGKV6_32","IGKV8_30","IGKV6_29","IGKV8_28","IGKV8_27","IGKV8_26","IGKV6_25","IGKV8_24","IGKV8_23_1","IGKV6_23","IGKV8_21","IGKV6_20","IGKV8_19","IGKV8_18","IGKV6_17","IGKV8_16","IGKV6_15","IGKV6_14","IGKV6_13","IGKV3_12","IGKV3_10","IGKV3_9","IGKV3_7","IGKV3_5","IGKV3_4","IGKV3_3","IGKV3_2","IGKV3_1","IGLV2","IGLV3","IGLV1","999")  # Add "IGKV14_126" and remove "IGKV1_35"
#IgJKL <- c("IGKJ1","IGKJ2","IGKJ4","IGKJ5","IGLJ2","IGLJ3","IGLJ1","999")

# Human
IgVKL <- c("IGKV1_5", "IGKV1_6", "IGKV1_8", "IGKV1_9", "IGKV1_12", "IGKV1_13", "IGKV1_16", "IGKV1_17", "IGKV1_27", "IGKV1_33", "IGKV1_39", "IGKV1D_8", "IGKV1D_12", "IGKV1D_13", "IGKV1D_16", "IGKV1D_17", "IGKV1D_33", "IGKV1D_39", "IGKV1D_43", "IGKV1_NL1", "IGKV2_24", "IGKV2_28", "IGKV2_29", "IGKV2_30", "IGKV2_40", "IGKV2D_26", "IGKV2D_28", "IGKV2D_29", "IGKV2D_30", "IGKV2D_40", "IGKV3_11", "IGKV3_15", "IGKV3_20", "IGKV3D_7", "IGKV3D_11", "IGKV3D_15", "IGKV3D_20", "IGKV4_1", "IGKV5_2", "IGKV6_21", "IGKV6D_21", "IGLV1_36", "IGLV1_40", "IGLV1_44", "IGLV1_47", "IGLV1_51", "IGLV2_8", "IGLV2_11", "IGLV2_14", "IGLV2_18", "IGLV2_23", "IGLV3_1", "IGLV3_9", "IGLV3_10", "IGLV3_16", "IGLV3_19", "IGLV3_21", "IGLV3_22", "IGLV3_25", "IGLV3_27", "IGLV4_3", "IGLV4_60", "IGLV4_69", "IGLV5_37", "IGLV5_39", "IGLV5_45", "IGLV5_52", "IGLV6_57", "IGLV7_43", "IGLV7_46", "IGLV8_61", "IGLV9_49", "IGLV10_54", "999")  # Human

IgJKL <- c("IGKJ1", "IGKJ2", "IGKJ3", "IGKJ4", "IGKJ5", "IGLJ1", "IGLJ2", "IGLJ3", "IGLJ6", "IGLJ7", "999")  #Human


###  Dump .txt Files of the Primary VDJ-Matrix #####
FileNameIdDump <- paste(DataName, "Dump.txt", sep = "")
dump("VJKL", file = FileNameIdDump)     # This is OK!! by > source("xxxx.txt")
####################

##  OutPut .txt of VJKL  ##
FileNameIdJ <- paste(DataName,"Dim2.txt", sep = "")
#write.table(VJKL,file = FileNameIdJ, append = F, sep = "\t", col.names = IgJKL, row.names = IgVKL)
write.table(VJKL,file = FileNameIdJ, append = F, sep = "\t", col.names = NA, row.names = IgVKL)      #colnames=NA
##

# test3 <- read.table("test1.txt", header = T, sep = "\t")  # test if "test1.txt" readable
#######################################

##  "VJKLDim1"  ###################

#VJKLDim1Data <- array(0, dim = c(840,2))
VJKLDim1Data <- array(0, dim = c(814,2))    # 74 x 11 = 814

j <- 0
k <- 0

n <- 0

for (k in 1:11) {
    for (j in 1:74) {
            
            n <- n + 1
            
            VjName <- paste (j, k, sep = "_")
            
            VJKLDim1Data[n, 1] <- VjName
            VJKLDim1Data[n, 2] <- VJKL[j, k]
            
    }
}

tmp1 <- VJKLDim1Data[,1]
tmp2 <- as.numeric(VJKLDim1Data[,2])

FileNameIdVJKLDim1 <- paste(DataName, "Dim1.txt", sep = "")
VJKLDim1 = data.frame(tmp1, tmp2)
colnames(VJKLDim1) <- c("VJ_Gene", "ReadCount")
write.table(VJKLDim1, file=FileNameIdVJKLDim1, sep="\t", append=F, row.names=F)

########################

#############################################################
### VJKLDim1_Rpm.txt
### Read "VJKLDim1.txt" > Get RPM > OutPut "VJKDim1Rpm.txt"
### 
###########################

in_f <- read.table(FileNameIdVJKLDim1, header=T, row.names=1, sep="\t", quote="")   #入力ファイル名を指定してin_fに格納

FileNameIdDim1Rpm <- paste(DataName, "Dim1Rpm.txt", sep = "")
out_f <- FileNameIdDim1Rpm              #出力ファイル名を指定してout_fに格納
param1 <- 1000000                       #補正後の総リード数を指定(RPMにしたい場合はここの数値はそのまま)

#入力ファイルの読み込み
data <- in_f
# data <- read.table(in_f, header=TRUE, row.names=1, sep="\t", quote="")    #in_fで指定したファイルの読み込み
head(data)                             #確認してるだけです
sum(data[,1])                          #総リード数を表示

#本番(正規化)
nf <- param1/sum(data[,1])             #正規化係数を計算した結果をnfに格納
out <- data[,1] * nf                   #正規化係数を各行に掛けた結果をoutに格納
head(out)                              #RPM変換後の数値を表示
sum(out)                               #総リード数を表示

#ファイルに保存
tmp <- cbind(rownames(data), data[,1], out)     #「ID, 配列長, カウント情報」の並びにしたものをtmpに格納
colnames(tmp) <- c("V_J", "Reads", "Count")     #列名を与えている
write.table(tmp, out_f, sep="\t", append=F, quote=F, row.names=F)   #tmpの中身をout_fで指定したファイル名で保存

########################
#   VJKLDim2Rpm.txt
#   Read "VJKLDim1Rpm.txt" >> OutPut "VJKLDim2Rpm.txt"
######################################

tmp3 <- read.table(FileNameIdDim1Rpm, header=TRUE, row.names=1, sep="\t", quote="")
#VJKLDim2Rpm <- array(tmp3[,2], dim=c(105,8))     # dim=c(105,8)に展開
VJKLDim2Rpm <- array(tmp3[,2], dim=c(74,11))     # dim=c(74,11)に展開

FileNameIdDim2Rpm <- paste(DataName, "Dim2Rpm.txt", sep = "")
#write.table(VJKLDim2Rpm, file = FileNameIdDim2Rpm, append = F, sep = "\t", col.names = IgJKL, row.names = IgVKL)
write.table(VJKLDim2Rpm, file = FileNameIdDim2Rpm, append = F, sep = "\t", col.names = NA, row.names = IgVKL)   # col.names = NA

####################################################################



###  END of PipeLine  ###############################














