#!/usr/bin/perl -w

###########################################################
#
#  04_KzIgBlast_N_ProductiveRandom_OutToExcel_ArgvRun_180312.pl
#
##  Run:  ###########################################
#
#   perl 04_KzIgBlast_N_ProductiveRandom_OutToExcel_ArgvRun_180312.pl IgBlastOutFile.txt OutPutFileName
#
################################
#
#       This is for extracting igblastn output file to excel (Tab_delimitated)
#
#
#   150730  Ver3    "Productive"-filteredIn
#   150707  Ver2
#   Ver1    150605
#
#
#
##  IgBlast example run:  ####################################
#
#   kzmcp2:Kz150605_igBLAST_TestRun_Ntd_2 ohnishik$ igblastn -germline_db_V $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghV_NtdDb.txt -germline_db_J $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghJ_NtdDb.txt -germline_db_D $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghD_NtdDb.txt -organism mouse -domain_system imgt -query myseq.Ntd.txt -auxiliary_data $IGDATA/optional_file/mouse_gl.aux -show_translation -outfmt 7 >> OutKz1506052
#
#######################################################################################


use strict;
use warnings;

## Prepare Start  #######

my ($output);

#print " Output file name? ", "\n";
#chomp ( $output = <STDIN>  );
chomp ( $output = $ARGV[1] );

#######################################

##  DataNameId? : ex. "Kz130823Kn130108Naive1IgM"  ########################

my ($DataNameId);
my ($output0);
my ($now);

use POSIX 'strftime';

$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print "\n",">> Started: $now", "\n";

# print " DataNameId? : ex. Kz130823Kn130108Naive1IgM ", "\n";
# chomp ( $DataNameId = <STDIN>  );           # Getting the "Prefix" for the output files
# open ( SUBFILE1, ">>$output" ) or die "Cannnot open SubSeq.fa", "\n";

#$DataNameId = $ARGV[1];
$DataNameId = $output;
$output0 = $DataNameId."_Log.txt";                                          # Set the name of Log_File: $output0
open ( SUBFILE0, ">>$output0" ) or die "Cannnot open SubSeq.fa", "\n";      # Open the Log_File

print SUBFILE0 "\n", "##  ", $output0, "  ## ";
print SUBFILE0 "\n", "! Started:: $now","\n";

################################################################



## Start  ####################

my ($SeqId);
my ($TopResultHit);
my ($TopResult);
my ($SeqNum);
my ($output1);

my($V_GENE_and_allele, $D_GENE_and_allele, $J_GENE_and_allele, $ChainType, $StopCodon, $JUNCTION_frame, $Functionality_comment, $Orientation);

my(@IGHVs, $num, $num2, @IGHDs, @IGHJs);

#$output1 = $DataNameId.".txt";                                              # Output_filename定義
$output1 = $DataNameId;             # Kz150714 for CompletePipeLine
open ( SUBFILE, ">>$output1" ) or die "Cannnot open SubSeq.fa", "\n";

open(MOM0,"$ARGV[0]"); 			#ファイルMOMをopenする

$TopResultHit=0;
$SeqNum=0;
while (<MOM0>)  {							# Read the line one by one
    
    chomp ( $_ );						# Remove the return at the last
    #print "\n","$_","\n";               # Test Print
    
    if ( $_ =~ /Query:/) {					# IF There is a SeqID,
        $SeqId=substr($_,9,14);
        #print "\n","$SeqId","\n";               # Test Print
        next;
    }
    
    if ( $_ =~ /Yes/) {      # $StopCodon-Yes or Productivity-Yesなら...　　　# IF there is a "Top Results...",##Aで始まり、その後に任意の2文字が続いた後、Dが続くパターン: /A..D/
        
        ($V_GENE_and_allele, $D_GENE_and_allele, $J_GENE_and_allele, $ChainType, $StopCodon, $JUNCTION_frame, $Functionality_comment, $Orientation) = split(/\t/,$_);
        
        if($Functionality_comment =~ /Yes/){        ## $Functionality_comment =~ /Yes/>> Productivity-Yesなら
            
            
            #        print $V_GENE_and_allele,"\t",$D_GENE_and_allele,"\t",$J_GENE_and_allele,"\t",$ChainType,"\t",$StopCodon,"\t",$JUNCTION_frame,"\t",$Functionality_comment,"\t",$Orientation,"\n";
            #        print SUBFILE $V_GENE_and_allele,"\t",$D_GENE_and_allele,"\t",$J_GENE_and_allele,"\t",$ChainType,"\t",$StopCodon,"\t",$JUNCTION_frame,"\t",$Functionality_comment,"\t",$Orientation,"\n";
            
            
            ##  ** 等価なIGHVのランダムな取得  ##########################################################################
            ##  配列へ代入の方法  ##
            #        # 文字列
            #        my $csv = "NM200102.1,NM200110.2,NM200121.1,NM200123.2";
            #        # カンマを区切り文字として分割し、その結果を@accession 配列に保存
            #        my @accession = split(/,/, $csv);
            #        # @accession 配列の全要素を出力
            #        for (my $i = 0; $i < @accession; $i++) {
            #            print $accession[$i] . "\n";
            ##################################################
            
            @IGHVs = split(/,/,$V_GENE_and_allele);
            
            ##  配列の要素数  ###########################
            #        # 最後の添字を取得(この場合は2。配列が空の場合は-1)
            #        $num = $#hoge;
            #        # 要素数を取得(この場合は3。配列が空の場合は0)
            #        $num = @hoge;
            ##############################
            
            $num = @IGHVs;
            
            ##  乱数の発生  ################################
            #        例えば1番目の引数に「10」が指定された場合は、0以上10未満の乱数が生成され返されます。生成される乱数は小数点を含む値です。
            #        具体的には次のように記述します。
            #        my $num = rand(10);
            #        乱数は小数点を含む数値となりますので、整数値だけの乱数を作成するには「int」関数を使って次のように記述します。
            #        my $num = int(rand(10));
            ###############################################
            
            $num2 = int(rand($num));
            
            $V_GENE_and_allele = $IGHVs[$num2];     # ランダム番目のUGHVを取得
            
            ##  **  ##############################################################################################################
            
            ## ++++++++++++
            
            ##  ** 等価なIGHDのランダムな取得  ##########################################################################
            
            @IGHDs = split(/,/,$D_GENE_and_allele);
            
            $num = @IGHDs;
            
            $num2 = int(rand($num));
            
            $D_GENE_and_allele = $IGHDs[$num2];     # ランダム番目のUGHDを取得
            
            ##  **  ##############################################################################################################
            
            ## ++++++++++++
            
            ##  ** 等価なIGHJのランダムな取得  ##########################################################################
            
            @IGHJs = split(/,/,$J_GENE_and_allele);
            
            $num = @IGHJs;
            
            $num2 = int(rand($num));
            
            $J_GENE_and_allele = $IGHJs[$num2];     # ランダム番目のUGHDを取得
            
            ##  **  ##############################################################################################################
            
            
            print $SeqId,"\t",$V_GENE_and_allele,"\t",$D_GENE_and_allele,"\t",$J_GENE_and_allele,"\t",$ChainType,"\t",$StopCodon,"\t",$JUNCTION_frame,"\t",$Functionality_comment,"\t",$Orientation,"\n";
            print SUBFILE $SeqId,"\t",$V_GENE_and_allele,"\t",$D_GENE_and_allele,"\t",$J_GENE_and_allele,"\t",$ChainType,"\t",$StopCodon,"\t",$JUNCTION_frame,"\t",$Functionality_comment,"\t",$Orientation,"\n";
            
            $SeqNum++;
            $SeqId="";
            $TopResult="";
            $TopResultHit=0;
            next;
            
        } else {
            next;
        }
        
    }
}


###  Log(0)  ###
$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print "\n",$now;

#print "\n", " -- The number of sequence trimed to $numlength was ( $hit ) out of ( $SeqNum ) -- ", "\n";
print SUBFILE0 "\n", " -- The number of sequence written as Productive(Randomized Top_VDJ) was ( $SeqNum ) -- ","\n",$now, "\n";
###




close ( SUBFILE0 );
close ( SUBFILE );
close ( MOM0 );



print "\n", " -- The number of sequence written was ( $SeqNum ) -- ","\n",$now, "\n";
print "\007";		# Beep
print "\007";
print "\007";

# End
		
