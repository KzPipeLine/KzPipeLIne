#!/usr/bin/perl -w

################
#
#   05_KzPipeLineAfterIgBlastPerl_Kz150714.pl
#
##### Run:  ##
#
#   perl 05_KzPipeLineAfterIgBlastPerl_Kz150714.pl  (IgBlastOut_Tabf(Excel))  (DataNameId:ex.　Kz130823Kn130108Naive1IgM　)
#   (Ex. ohnishik$ perl 01_KzPipeLineAfterIgBlastPerl_Kz150710_2.pl test2.txt test2_2)
#
#
############################################################
###########
#
#   00_Kz131024Perl_454VdjPipeLineNdIncl.pl << Add 00_Kz131024Perl_454VdjPipeLineNdIncl.pl
#
#
#   Ver1: 131229
#   Ver2: 140102
#   Ver3: 140108    Vh > On Chromosome Order
#   Ver4: 140115    Dh: IGHD3-3 omitted, IGHD2-7 added, ChrOrder(IGHD3-1ComesTo1st)
#
##### Run:  ##
#
#
############################################################
###     130828 >> Making 454VdjPipeLine
###     Arguments are (2): Data DataNameId
###     130903: "ND" included.
#############################

##  DataNameId? : ex. "Kz130823Kn130108Naive1IgM"

my ($DataNameId);
my ($output0);
my ($now);

use POSIX 'strftime';

$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print "\n",">> Started: $now", "\n";

# print " DataNameId? : ex. Kz130823Kn130108Naive1IgM ", "\n";
# chomp ( $DataNameId = <STDIN>  );           # Getting the "Prefix" for the output files
# open ( SUBFILE1, ">>$output" ) or die "Cannnot open SubSeq.fa", "\n";

$DataNameId = $ARGV[1];
$output0 = $DataNameId."_Log.txt";                                          # Set the name of Log_File: $output0
open ( SUBFILE0, ">>$output0" ) or die "Cannnot open SubSeq.fa", "\n";      # Open the Log_File

print SUBFILE0 "\n", "##  ", $output0, "  ## ";
print SUBFILE0 "\n", "! Started:: $now","\n";

###  (1) KzMFImgtTabF_ProdFasta.pl  ###############
###########################################################
# Kz121002Impt_ImgtTabFile.pl
####################################################
#       The original of KzMFImgtTabF
#       This is for reading IMGT_Summary File (Tab_delimited) and Output the target fields to MultiFasta file.
#               MFasta file_A
#               > Find the read-ID one by one
#               > Lock at the same read-ID entry in the file_B
#               > Output the hit entry to the SUBFILE named as the input
#
#######################################################################################

################################################################
#The Summary sheet includes:
#
#    Sequence number
#    Sequence ID
#    Functionality: provides the functionality. A message [(see comment)] may be added. It indicates that a comment related to the functionality has been added in the column [Functionality comment]
#    V-GENE and allele: provides the closest V-GENE and allele name(s). A message [(see comment)] may be added. It indicates that a comment related to potential insertions and/or deletions has been added in the column [V-REGION potential ins/del].
#    V-REGION score
#    V-REGION identity %
#    V-REGION identity nt
#    V-REGION identity % (with ins/del events): this field is shown if the option [Search for insertions and deletions] is selected. It indicates the percentage of identity and ratio considering each insertion or deletion as one mutational event. For each insertion or deletion, whatever its length, "1" is subtracted from the number of identical nucleotides
#    V-REGION identity nt (with ins/del events): this field is shown if the option [Search for insertions and deletions] is selected. It indicates the percentage of identity and ratio considering each insertion or deletion as one mutational event. For each insertion or deletion, whatever its length, "1" is subtracted from the number of identical nucleotides
#    J-GENE and allele: provides the closest J-GENE and allele name(s). A message [(see comment)] may be added. It indicates that a comment related to other possibilities for the J identification has been added in the column [J-GENE and allele comment].
#    J-REGION score
#    J-REGION identity %
#    J-REGION identity nt
#    D-GENE and allele: provides the closest D-GENE and allele name(s) identified by IMGT/JunctionAnalysis
#    D-REGION reading frame
#    CDR1-IMGT length
#    CDR2-IMGT length
#    CDR3-IMGT length
#    CDR-IMGT lengths
#    FR-IMGT lengths
#    AA JUNCTION (with restored frameshift for out-of-frame junctions, indicated with # in the sequence)
#    JUNCTION frame
#    Orientation: a sign + indicates [sense] orientation for the cDNA. A sign - indicates [antisens orientation] and therefore, that the sequence was complementary reversed for the IMGT/V-QUEST analysis.
#    Functionality comment: explains why a sequence has been identified as [unproductive]
#    V-REGION potential ins/del: this field is filled if the option [Search for insertions and deletions] is not selected and if insertions or deletions may be suspected.
#    J-GENE and allele comment: this field is filled if other possibilities exist for the choice of the J-GENE and allele
#    V-REGION insertions: this field is shown if the option [Search for insertions and deletions] is selected. It indicates the localization of the insertion(s)
#    V-REGION deletions: this field is shown if the option [Search for insertions and deletions] is selected. It indicates the localization of the deletion(s)
#    Sequence: the user sequence
#
#    Note that :
#        if the option "Search for insertions and deletions" is selected and if insertions have been detected, they appear in capital letters in the user sequence. The results provided in the other sheets of # # the Excel file correspond to the IMGT/V-QUEST analysis after removal of the insertions.
#        The AA JUNCTION is not provided only if the JUNCTION can't be analysed by IMGT/JunctionAnalysis.
######################################################

use strict;
use warnings;

# my ($output);
my ($output1);
my ($prod);
my ($seqid);
my ($hit);

my ($Sequence_number);
my ($Sequence_ID);
my ($Functionality);
my ($V_GENE_and_allele);
my ($V_REGION_score);
my ($V_REGION_identity_pc);
my ($V_REGION_identity_nt);
my ($ibid_pc_with_insdel);	
my ($ibid_nt_with_insdel);
my ($J_GENE_and_allele);
my ($J_REGION_score);
my ($J_REGION_identity_pc);
my ($J_REGION_identity_nt);
my ($D_GENE_and_allele);
my ($D_REGION_reading_frame);
my ($CDR1_IMGT_length);
my ($CDR2_IMGT_length);
my ($CDR3_IMGT_length);
my ($CDR_IMGT_lengths);
my ($FR_IMGT_lengths);
my ($AA_JUNCTION);
my ($JUNCTION_frame);
my ($Orientation);
my ($Functionality_comment);
my ($V_REGION_potential_insdel);
my ($J_GENE_and_allele_comment);
my ($V_REGION_insertions);
my ($V_REGION_deletions);
my ($Sequence);

my ($ChainType);
my ($StopCodon);


###  (1) (Equivalent to) KzVdjSort3FrmMF.pl  ###############
#       150710  改 for IgBlast_Productive
###########################################################
# KzVdjSort3FrmMF.pl
####################################################
#       The derivative of KzVdjSort.pl
#       This is for the assignment of specific gene_number for IghV, IghD, IghJ,
#			reading the OUTPUT of "KzMFImgtTabF_ProdFasta.pl ( not from KzMFImgtTabF_ProdExcel.pl" )
#		The OUTPUT subfile:
#			>$Sequence_ID, "\t",$V_GENE_and_allele, "\t",$D_GENE_and_allele, "\t",$J_GENE_and_allele
#			$V_GENE,"\t",$D_GENE,"\t",$J_GENE
#
#			$V_GENE: 110	$D_GENE: 10 > 12 (OK)	$J_GENE: 4
#
#		Ver.1: 130510
#		Ver.2: 130516		> $vtarget definition, before "_01"
#							> $nd: Not Defined
#       Ver.3: 130801       > 12 Dh Genes for Major IMGT-assignment
#       130813 > FrmMF
#
#######################################################################################

use strict;
use warnings;


# !! The Numbers starts with 0 as it is perl !!
# The input is the OUTPUT of "KzMFImgtTabF_ProdExcel.pl"



my (@IghV, @IghD, @IghJ);
my ($v, $d, $j);
my $i = 0;
my $ii = 0;
my $vl = 0;
my $ndv = 0;
my $ndd = 0;
my $ndj = 0;
# my $dl = 0;
# my $jl = 0;



# my ($output);
# my ($prod);
# my ($seqid);
my ($read);

# my ($Sequence_ID);
# my ($V_GENE_and_allele);
# my ($D_GENE_and_allele);
# my ($J_GENE_and_allele);
# my ($AA_JUNCTION);
# my ($Sequence);

# my ($V_REGION_identity_pc);
# my ($CDR_IMGT_lengths);

my ($vtarget);
my ($dtarget);
my ($jtarget);

my ($V_GENE,$D_GENE,$J_GENE);

my (@VdjMtx1, @VdjMtx2);

my ($search01);

# -----------------------

#@IghV = ("IGHV1_4","IGHV1_5","IGHV1_7","IGHV1_9","IGHV1_11","IGHV1_12","IGHV1_14","IGHV1_15","IGHV1_16","IGHV1_17_1","IGHV1_18","IGHV1_19","IGHV1_20","IGHV1_22","IGHV1_23","IGHV1_26","IGHV1_31","IGHV1_34","IGHV1_36","IGHV1_37","IGHV1_39","IGHV1_42","IGHV1_43","IGHV1_47","IGHV1_49","IGHV1_50","IGHV1_52","IGHV1_53","IGHV1_54","IGHV1_55","IGHV1_56","IGHV1_58","IGHV1_59","IGHV1_61","IGHV1_62_1","IGHV1_62_2","IGHV1_62_3","IGHV1_63","IGHV1_64","IGHV1_66","IGHV1_67","IGHV1_69","IGHV1_71","IGHV1_72","IGHV1_74","IGHV1_75","IGHV1_76","IGHV1_77","IGHV1_78","IGHV1_80","IGHV1_81","IGHV1_82","IGHV1_84","IGHV1_85","IGHV2_2","IGHV2_3","IGHV2_4","IGHV2_5","IGHV2_6","IGHV2_7","IGHV2_9","IGHV3_1","IGHV3_3","IGHV3_4","IGHV3_5","IGHV3_6","IGHV3_8","IGHV4_1","IGHV5_2","IGHV5_4","IGHV5_6","IGHV5_9","IGHV5_12","IGHV5_15","IGHV5_16","IGHV5_17","IGHV6_3","IGHV6_4","IGHV6_5","IGHV6_6","IGHV6_7","IGHV7_2","IGHV7_3","IGHV7_4","IGHV8_2","IGHV8_4","IGHV8_5","IGHV8_6","IGHV8_8","IGHV8_9","IGHV8_11","IGHV8_12","IGHV8_13","IGHV9_1","IGHV9_2","IGHV9_3","IGHV9_4","IGHV10_1","IGHV10_3","IGHV11_1","IGHV11_2","IGHV12_3","IGHV13_1","IGHV13_2","IGHV14_1","IGHV14_2","IGHV14_3","IGHV14_4","IGHV15_2","IGHV16_1");

@IghV = ("IGHV1_85","IGHV1_84","IGHV1_82","IGHV1_81","IGHV1_80","IGHV1_78","IGHV1_77","IGHV1_76","IGHV1_75","IGHV1_74","IGHV8_13","IGHV1_72","IGHV1_71","IGHV8_12","IGHV1_69","IGHV1_67","IGHV1_66","IGHV8_11","IGHV1_64","IGHV1_63","IGHV8_9","IGHV1_62_3","IGHV1_62_2","IGHV1_62_1","IGHV1_61","IGHV1_59","IGHV1_58","IGHV8_8","IGHV1_56","IGHV1_55","IGHV1_54","IGHV8_6","IGHV1_53","IGHV1_52","IGHV1_50","IGHV8_5","IGHV1_49","IGHV8_4","IGHV1_47","IGHV1_43","IGHV1_42","IGHV1_39","IGHV1_37","IGHV1_36","IGHV1_34","IGHV1_31","IGHV1_26","IGHV1_23","IGHV1_22","IGHV1_19","IGHV1_20","IGHV1_18","IGHV1_17_1","IGHV1_16","IGHV1_15","IGHV1_14","IGHV1_12","IGHV1_11","IGHV1_9","IGHV15_2","IGHV1_7","IGHV10_3","IGHV1_5","IGHV1_4","IGHV10_1","IGHV8_2","IGHV6_7","IGHV6_6","IGHV6_5","IGHV6_4","IGHV6_3","IGHV12_3","IGHV13_2","IGHV3_8","IGHV9_4","IGHV3_6","IGHV13_1","IGHV3_5","IGHV3_4","IGHV7_4","IGHV3_3","IGHV14_4","IGHV7_3","IGHV9_3","IGHV9_2","IGHV9_1","IGHV16_1","IGHV14_3","IGHV11_2","IGHV14_2","IGHV11_1","IGHV3_1","IGHV4_1","IGHV14_1","IGHV7_2","IGHV2_9","IGHV5_17","IGHV5_16","IGHV5_15","IGHV2_7","IGHV2_6","IGHV5_12","IGHV2_5","IGHV5_9","IGHV2_4","IGHV5_6","IGHV2_3","IGHV5_4","IGHV2_2","IGHV5_2");

@IghD = ("IGHD3_1","IGHD1_1","IGHD1_2","IGHD1_3","IGHD2_1","IGHD2_2","IGHD2_3","IGHD2_4","IGHD2_5","IGHD2_7","IGHD3_2","IGHD4_1");

@IghJ = ("IGHJ1","IGHJ2","IGHJ3","IGHJ4");

# ---------------------

open(DATAFILE,"$ARGV[0]") or die("error :$!");

my ($output2);
    $output2 = $DataNameId."_VdjSort.fna.txt";               # Set the name of OUTPUT_File: $output2 << $DataNameId."_VdjSort.fna.txt"
    open ( SUBFILE2, ">>$output2" ) or die "Cannnot open SubSeq.fa", "\n";

$read = 0;

while (<DATAFILE>)  {
    
        chomp ($_);
        $_ =~ tr/-*/__/;
        #	print "\n", $_, "\n";
        
        $read++;
        
        $V_GENE = "";
        $D_GENE = "";
        $J_GENE = "";
        
    
        ($Sequence_ID, $V_GENE_and_allele, $D_GENE_and_allele, $J_GENE_and_allele, $ChainType, $StopCodon, $JUNCTION_frame, $Functionality_comment, $Orientation) = split(/\t/,$_);
    
        print "\n","Sequence_ID: ", $Sequence_ID;
        print "\n","V_GENE_and_allele: ", $V_GENE_and_allele;
        print "\n","D_GENE_and_allele: ", $D_GENE_and_allele;
        print "\n","J_GENE_and_allele: ", $J_GENE_and_allele,"\n";
        #	print "\n","AA_JUNCTION: ", $AA_JUNCTION;
        #	print "\n","Sequence: ", $Sequence;
        
        #	print "\n","IghV genes number: ", $#IghV,"\n";
        
        
        $vl = 0;
        $vtarget = "";
        $ii = 0;
        
#        $seqid=substr($Sequence_ID,1,15);          ## Imgt_Summaryの場合
        $seqid=$Sequence_ID;        # IgBlast_Outの場合
    
        
    ###########	Find the "_01" in $V_GENE_and_allele and set the length $ii for the $vtarget  ################
    
    #$search01 = substr($V_GENE_and_allele,7);       # Imgt_Summaryでは、”Musmus IGHV3-6*01”
    $search01 = $V_GENE_and_allele;
    
        foreach my $ii (0..length $search01) {
            
                if (substr( $search01, $ii, 2) eq "_0")  {
                #			print "\n","ii = ","$ii","\n";		# print the length to _01
                $vtarget = substr($V_GENE_and_allele, 0, $ii);
                print "\n","vtarget = ","$vtarget","\n";		# print the $vtarget
                last;
            }
        }
        
        
        
        
        # Find IghV_gene Number : $v
        $V_GENE = 110;                              # ND for IgV gene o be 110
        for $v (0..$#IghV) {
            
            # $vl = length($IghV[$v]);							# Here Problem!!! >> Look "_01"
            # $vtarget = substr($V_GENE_and_allele, 0, $vl);		# Here Problem!!! >> Look "_01"
            
            
            #		print "\n","IghV:", $IghV[$v];
            #		print "\n","vtarget: ", $vtarget,"\n";
            
            
            if ($vtarget eq $IghV[$v]){
                #	print "\n"," Hit!!! ", $IghV[$v]," Hit_$v ", $v ;
                $V_GENE = $v;
                last;
            }
        }
		
        if ($V_GENE == 110){
            $ndv++;
        }
        
        #######################  Find IghD_gene Number : $d  ###############################
    
    #$dtarget = substr($D_GENE_and_allele,7);            # Imgt_Summaryでは、”Musmus IGHV3-6*01”
    $search01 = $D_GENE_and_allele;
    print "\n","dtarget: ", $search01;
    
    foreach my $ii (0..length $search01) {
        
        if (substr( $search01, $ii, 2) eq "_0")  {
            #			print "\n","ii = ","$ii","\n";		# print the length to _01
            $dtarget = substr($D_GENE_and_allele, 0, $ii);
            print "dtarget = ","$dtarget","\n","\n";		# print the $vtarget
            last;
        }
    }
    
        # Find IghD_gene Number : $d
        $D_GENE = 12;
        for $d (0..$#IghD) {
            
#            $dtarget = "";
            
            if ($D_GENE_and_allele eq ""){
                last;
            }
            
            if ($dtarget eq $IghD[$d]){
                print "\n"," Hit!!! ", $IghD[$d]," Hit_$d ", $d ;
                $D_GENE = $d;
                last;
            }
        }
        
        if ($D_GENE == 12){
            $ndd++;
        }
        
        ########################  Find IghJ_gene Number : $j  ##########################
        $J_GENE = 4;
        for $j (0..$#IghJ) {
            
            $jtarget = "";
            
            #$jtarget = substr($J_GENE_and_allele,7,5);      # Imgt_Summaryでは、”Musmus IGHV3-6*01”
            $jtarget = substr($J_GENE_and_allele,0,5);
            #	print "\n","jtarget: ", $jtarget;
            if ($jtarget eq $IghJ[$j]){
                #	print "\n"," Hit!!! ", $IghJ[$j]," Hit_$j ", $j ;
                $J_GENE = $j;
                last;
            }
        }
        
        if ($J_GENE == 4){
            $ndj++;
        }
		
    ##########  ***  ##########################
    
        print ">", $seqid, "\t",$V_GENE_and_allele, "\t",$D_GENE_and_allele, "\t",$J_GENE_and_allele,"\n";
        print $V_GENE,"\t",$D_GENE,"\t",$J_GENE,"\n";
        
        print SUBFILE2 ">", $seqid, "\t",$V_GENE_and_allele, "\t",$D_GENE_and_allele, "\t",$J_GENE_and_allele,"\n";
        print SUBFILE2 $V_GENE,"\t",$D_GENE,"\t",$J_GENE,"\n";
        
    }

close (SUBFILE2);
close (DATAFILE);

###  Log(2)  ###
$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print "\n",$now;

print "\n", " -- Done(1): Step_1::(EquivalentTo)KzVdjSort3FrmMF.pl -- ", " [ ",$read," Sequences Try Assigned, ND: V=",$ndv," D=",$ndd," J=", $ndj," ]","\n";
print SUBFILE0 "\n", " -- Done(1): Step_1::(EquivalentTo)KzVdjSort3FrmMF.pl -- ", " [ ",$read," Sequences Try Assigned, ND: V=",$ndv," D=",$ndd," J=", $ndj," ]","\n",$now, "\n";
###

print "\007";
# print "\007";
# print "\007";

###  End of (1)  ################################



#########################################################################



###  (2) KzMFRmCmLnNd.pl  ###############
########################################################
#    KzMFRmCmLnNd.pl
#########################################
# The Derivative of KzMFRmCmLn.pl
# This is for Removing Comment Line, ie. (> Line)
# Moreover the line containing "ND" is omitted (in order for "R")
# Output to .txt File (Such as VhDhJh Output from KzVdjSort2.pl)
# Ver.1     130730
##############################################

# use strict;

my ($numseq);
my ($search_string);
# my ($i);
my ($NdNum);


$numseq = 0;
$NdNum = 0;
$i = 0;

open(DATAFILE2, "< $output2") or die("error :$!");             ## < SUBFILE from the above (1)

#   print " Output file name? ", "\n";
#   chomp ( $output = <STDIN>  );
#   open ( SUBFILE1, ">>$output" ) or die "Cannnot open SubSeq.fa", "\n";

my ($output4);
$output4 = $DataNameId."_VdjSortRmCmLn.fna.txt";               # Set the name of Log_File: $output1 << $DataNameId."_Prod.fna.txt"
open ( SUBFILE4, ">$output4" ) or die "Cannnot open S$output4", "\n";

#   print " Output file name? :: .txt", "\n";
#   chomp ( $output = <STDIN>  );
#   open ( SUBFILE, ">>$output" ) or die "Cannnot open SUBFILE", "\n";



LOOK: while (<DATAFILE2>)  {
	chomp ( $_ );
	if ( $_ =~ /^>/ ) {
        
        next;
        
        #   print "$_", "\n";
        #   print SUBFILE "$_", "\n";
        
	} else {
        
        $numseq++;
        print "$numseq", "\n";
        
        $search_string = $_;
        #		foreach my $i (0..length $search_string) {
        #			if (substr( $search_string, $i, 2) eq "ND")  {
        #				$NdNum++;
        #                next LOOK;
        #            }
        #        }        
        #   print "$_", "\n";
        print SUBFILE4 "$_", "\n";
        
    }
}

close ( DATAFILE2 );
close ( SUBFILE4 );

###  Log(2)  ###
$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print "\n",$now;

print "\n", " -- Done(Step_2) and All:(Equivalent to) KzMFRmCmLnNd.pl -- "," [ The number of entry(>) scanned: ( $numseq ) && ND = ( $NdNum ) ] ", "\n";
print SUBFILE0 "\n", " -- Done(Step_2) and All:(Equivalent to) KzMFRmCmLnNd.pl -- ", " [ The number of entry(>) scanned: ( $numseq ) && ND = ( $NdNum ) ] ", "\n",$now, "\n";
###


# print " -- The number of entry(>) scanned: ( $numseq ) && ND = ( See above ) -- ", "\n";
print "\007";
print "\007";
print "\007";

###  End of (4)  ################################

close (SUBFILE0);


###  End of All  ################################
###################################################################
