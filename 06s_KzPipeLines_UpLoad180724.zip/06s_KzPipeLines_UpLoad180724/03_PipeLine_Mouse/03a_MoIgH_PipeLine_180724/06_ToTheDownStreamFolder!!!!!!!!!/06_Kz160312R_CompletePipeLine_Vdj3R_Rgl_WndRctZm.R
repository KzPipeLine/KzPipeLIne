##################
##  06_Kz160312R_CompletePipeLine_Vdj3R_Rgl_WndRctZm.R
#############
##
##
##  150908  scene3d() > Comment << KzMcP2はH.264で遅くなる！！！
##  140115  IGHV ChrOrder!!
##  140115  IGHD3-3 omitted, IGHD2-7 added
##  140109  Implant from 00Kz1401085R_VdjRglAbclinesJhMesh.R
##  140108: Add JhMesh
##  140108: Add Vh_label
##
##### Run:
##
##  > (Data1 <- read.table("Kz150714_Amplicons_20130904.fna_2k_KzMfIgM_RL1_IgBlastProd_VdjSortRmCmLn.fna.txt"))
##  > DataName <- "Kz150714_Amplicons_20130904.fna_2k_KzMfIgM_RL1_IgBlastProd_VdjSortRmCmLn.fna"
##  > source("06_Kz160308R_CompletePipeLine_Vdj3R_Rgl_WndwRect.R")
##
##
###########################
##  140714: Abclines3d modified
##  130903: Nd = 999 included >> Red_shepheres
###################################


##  "KzR_MatrixData1ToVDJ1_130814.R"  ###########

VDJ1 <- array(0, dim = c(111,13,5))

# cat(length(Data1$V1))

VV <- 0
DD <- 0
JJ <- 0

for (i in 1:length(Data1$V1)){

    VV <- Data1[i,1] 
    DD <- Data1[i,2]
    JJ <- Data1[i,3]
    
    VV <- VV + 1
    DD <- DD + 1
    JJ <- JJ + 1
    
    
#    cat(VV, DD, JJ)

    VDJ1[VV, DD, JJ] <- VDJ1[VV, DD, JJ] + 1
    
}

#IgVH <- c("1_4","1_5","1_7","1_9","1_11","1_12","1_14","1_15","1_16","1_17_1","1_18","1_19","1_20","1_22","1_23","1_26","1_31","1_34","1_36","1_37","1_39","1_42","1_43","1_47","1_49","1_50","1_52","1_53","1_54","1_55","1_56","1_58","1_59","1_61","1_62_1","1_62_2","1_62_3","1_63","1_64","1_66","1_67","1_69","1_71","1_72","1_74","1_75","1_76","1_77","1_78","1_80","1_81","1_82","1_84","1_85","2_2","2_3","2_4","2_5","2_6","2_7","2_9","3_1","3_3","3_4","3_5","3_6","3_8","4_1","5_2","5_4","5_6","5_9","5_12","5_15","5_16","5_17","6_3","6_4","6_5","6_6","6_7","7_2","7_3","7_4","8_2","8_4","8_5","8_6","8_8","8_9","8_11","8_12","8_13","9_1","9_2","9_3","9_4","10_1","10_3","11_1","11_2","12_3","13_1","13_2","14_1","14_2","14_3","14_4","15_2","16_1","999")
IgVH <- c("1_85","1_84","1_82","1_81","1_80","1_78","1_77","1_76","1_75","1_74","8_13","1_72","1_71","8_12","1_69","1_67","1_66","8_11","1_64","1_63","8_9","1_62_3","1_62_2","1_62_1","1_61","1_59","1_58","8_8","1_56","1_55","1_54","8_6","1_53","1_52","1_50","8_5","1_49","8_4","1_47","1_43","1_42","1_39","1_37","1_36","1_34","1_31","1_26","1_23","1_22","1_19","1_20","1_18","1_17_1","1_16","1_15","1_14","1_12","1_11","1_9","15_2","1_7","10_3","1_5","1_4","10_1","8_2","6_7","6_6","6_5","6_4","6_3","12_3","13_2","3_8","9_4","3_6","13_1","3_5","3_4","7_4","3_3","14_4","7_3","9_3","9_2","9_1","16_1","14_3","11_2","14_2","11_1","3_1","4_1","14_1","7_2","2_9","5_17","5_16","5_15","2_7","2_6","5_12","2_5","5_9","2_4","5_6","2_3","5_4","2_2","5_2","999")
IgVD <- c("3_1","1_1","1_2","1_3","2_1","2_2","2_3","2_4","2_5","2_7","3_2","4_1","999")
IgVJ <- c("1","2","3","4","999")


###  Dump .txt Files of the Primary VDJ-Matrix #####
FileNameIdDump <- paste(DataName, "_Dump.txt", sep = "")
dump("VDJ1", file = FileNameIdDump)     # This is OK!! by > source("xxxx.txt")
####################

##  OutPut .txt of VDJ1  ##
for (i2 in 1:5){
FileNameIdJ <- paste(DataName, "_Jh", i2, ".txt", sep = "")
write.table(VDJ1[1:111,1:13,i2],file = FileNameIdJ, append = F, sep = "\t", col.names = IgVD, row.names = IgVH)
}
##

# test3 <- read.table("test1.txt", header = T, sep = "\t")  # test if "test1.txt" readable
#######################################

##  "KzR_VDJ1ToVdj1Dim1_130820.R"  ###################

Vdj1Dim1Data <- array(0, dim = c(7215,2))

i <- 0
j <- 0
k <- 0

n <- 0

for (k in 1:5) {
    for (j in 1:13) {
        for (i in 1:111) {
            
            n <- n + 1
            
            VdjName <- paste (i, j, k, sep = "_")
            
            Vdj1Dim1Data[n, 1] <- VdjName
            Vdj1Dim1Data[n, 2] <- VDJ1[i, j, k]
            
        }
    }
}

tmp1 <- Vdj1Dim1Data[, 1]
tmp2 <- as.numeric(Vdj1Dim1Data[, 2])

Vdj1Dim1 = data.frame(tmp1, tmp2)
colnames(Vdj1Dim1) <- c("VdjGene", "ReadCount")
write.table(Vdj1Dim1, "Vdj1Dim1.txt", sep="\t", append=F, row.names=F)

########################

#############################################################
### KzR_RpmVdj1Dim1_130820.R
### Read "Vdj1Dim1.txt" > Get RPM > OutPut "Vdj1Dim1Rpm.txt"
### And Get Vdj1RpmDim3 <- array(tmp2[,2], dim=c(111,13,5))
###########################

in_f <- read.table("Vdj1Dim1.txt", header=T, row.names=1, sep="\t", quote="")   #入力ファイル名を指定してin_fに格納

FileNameIdDim1Rpm <- paste(DataName, "_Dim1Rpm.txt", sep = "")
out_f <- FileNameIdDim1Rpm              #出力ファイル名を指定してout_fに格納
param1 <- 1000000                       #補正後の総リード数を指定(RPMにしたい場合はここの数値はそのまま)

#入力ファイルの読み込み
data <- in_f
# data <- read.table(in_f, header=TRUE, row.names=1, sep="\t", quote="")    #in_fで指定したファイルの読み込み
head(data)                             #確認してるだけです
sum(data[,1])                          #総リード数を表示

#本番(正規化)
nf <- param1/sum(data[,1])             #正規化係数を計算した結果をnfに格納
out <- data[,1] * nf                   #正規化係数を各行に掛けた結果をoutに格納
head(out)                              #RPM変換後の数値を表示
sum(out)                               #総リード数を表示

#ファイルに保存
tmp <- cbind(rownames(data), data[,1], out)     #「ID, 配列長, カウント情報」の並びにしたものをtmpに格納
colnames(tmp) <- c("V_D_J", "Reads", "Count")     #列名を与えている
write.table(tmp, out_f, sep="\t", append=F, quote=F, row.names=F)   #tmpの中身をout_fで指定したファイル名で保存

tmp2 <- read.table(FileNameIdDim1Rpm, header=TRUE, row.names=1, sep="\t", quote="")
Vdj1RpmDim3 <- array(tmp2[,2], dim=c(111,13,5))     # dim=c(111,13,4)に展開
##  OutPut .txt of Vdj1RpmDim3  #####################
for (i3 in 1:5){
FileNameIdRpmJ <- paste(DataName, "Rpm", "_Jh", i3, ".txt", sep = "")
write.table(Vdj1RpmDim3[1:111,1:13,i3], file = FileNameIdRpmJ, append = F, sep = "\t", col.names = IgVD, row.names = IgVH)
}
####################################################################

#########################################################
### KzR_BallVrVdj1_130821.R
### Get Radii of Ball_Volume of Vdj1RpmDim3
### OutPut to VDJ1BallVr
##############################

VDJ1 <- Vdj1RpmDim3

VDJ1BallVr <- array(0, dim = c(111,13,5))

i <- 0
j <- 0
k <- 0

for (i in 1:111) {
    for (j in 1:13) {
        for (k in 1:5) {
            
            if (VDJ1[i, j, k] == 0) {
            
                VDJ1BallVr[i, j, k] <- 0
            
            } else {
                
                Vol <- VDJ1[i, j, k]
                rad <- ((3*Vol)/(4*pi))**(1/3)
                VDJ1BallVr[i, j, k] <- rad
            
            }
            
        }
    }
}

###  Dump .txt Files of BallVrVdj1 ###
FileNameId_BallVrVdj1_Dump <- paste(DataName, "_BallVrVdj1_Dump.txt", sep = "")
dump("VDJ1BallVr", file = FileNameId_BallVrVdj1_Dump, , append = FALSE)     # This is OK!! by > source("xxxx.txt")
###

###  OutPut .txt of VDJ1BallVr  ###
for (i4 in 1:5){
FileNameIdRpmBallVrJ <- paste(DataName, "RpmBallVr", "_Jh", i4, ".txt", sep = "")
write.table(VDJ1BallVr[1:111,1:13,i4],file = FileNameIdRpmBallVrJ, append = F, sep = "\t", col.names = IgVD, row.names = IgVH)
}
###

################################

#################################################################
### KzR_Vdj1Rgl_VDJ1BallVr_130821.R
### Rgl_Plot of VDJ1BallVr
###############################

VDJ1 <- VDJ1BallVr

library(rgl)

clear3d(type="all")

rgl.light(theta =   50, phi =  20, viewpoint.rel = F, ambient = "white", diffuse = "white", specular = "white")
rgl.light(theta =  -50, phi =  20, viewpoint.rel = F, ambient = "white", diffuse = "white", specular = "white")
rgl.light(theta =   50, phi = -20, viewpoint.rel = F, ambient = "white", diffuse = "white", specular = "white")


#Kz1windowRect <- c(77, 78, 1744, 1285)
#Kz1windowRect <- c(77, 78, 1667, 1207)      # << 160308
Kz1windowRect <- c(50, 50, 800, 600)      # << 160312
#Kz1zoom <- c(0.7106816)
#Kz1zoom <- c(1.0)                           # << 160312
Kz1zoom <- c(0.72)                     # <<< 160312
Kz1userMatrix <- array(c(0.94480813, 0.06981283, -0.32009903, 0.00000000, -0.3252229, 0.3179117, -0.8905965, 0.0000000, 0.03958809, 0.94554657, 0.32307026, 0.00000000, 0, 0, 0, 1), dim = c(4,4))

bbox3d()

par3d(windowRect=Kz1windowRect)
par3d(zoom=Kz1zoom)
par3d(userMatrix=Kz1userMatrix)

i <- 0
j <- 0
k <- 0

for (i in 1:111) {
    for (j in 1:13) {
        for (k in 1:5) {
            
            x1 <- i
            y1 <- j
            z1 <- k
            c1 <- VDJ1[i, j, k]
            
            if(k == 5){
                rgl.spheres(x1, y1, z1, radius = c1/2, specular = "#FFFFFF", ambient = "#222222", color = "Red")   
            }

            if(j == 13){
                rgl.spheres(x1, y1, z1, radius = c1/2, specular = "#FFFFFF", ambient = "#222222", color = "Red")
            }
            
            if(i == 111){
                rgl.spheres(x1, y1, z1, radius = c1/2, specular = "#FFFFFF", ambient = "#222222", color = "Red")
            }
            
            rgl.spheres(x1, y1, z1, radius = c1/2, specular = "#FFFFFF", ambient = "#222222", color = "Blue")
            
        }
    }
}


aspect3d(x = 8, y = 2, z = 4)
# rgl.bbox(color=c("white", "#333377"), emission="white", specular="#3333FF", shininess=5, alpha=1, marklen.rel = T, xunit = 1, yunit = 1, zunit = 1, xlab = IgVH, ylab = IgVD, zlab = IgVJ)

# bbox3d(color=c("white", "#333377"), emission="white", specular="#3333FF", shininess=5, alpha=1)

bg3d("white")

axes3d(col = "black", lwd = 1)

axes3d(edges = "x", labels = IgVH, tick = TRUE, nticks = 111, expand = 3.0, cex=0.3, adj = c(0,0), srt=90)    #Impt!!!

### 各方向の基準線（onND)を描く:_1
i <- 0
j <- 0
k <- 0

#for (i in 1:111) {
for (j in 1:13) {
    for (k in 1:5) {
        
        a2 <- i
        b2 <- j
        c2 <- k
        #abclines3d(a2,b2,c2, a=diag(3), col="gray")
        #abclines3d(10,b2,0, a=diag(3), col="gray")
        #abclines3d(10,0,c2, a=diag(3), col="gray")
        #abclines3d(a2,6,0, a=diag(3), col="gray")
        #abclines3d(0,6,c2, a=diag(3), col="gray")
        #        abclines3d(-10,b2,c2, a=diag(3), col="gray")       ## x,y,z: Coordinates of points through which each line passes.
        abclines3d(112,b2,c2, a=diag(3), col="gray")     ## -1は線を消すため;112は奥に縦線
        #abclines3d(a2,y=NULL,c2, a=diag(3), col="gray")
        #abclines3d(a2,y=-5,c2, a=diag(3), col="gray")
        
    }
}
#}
#####

### 各方向の基準線（onND)を描く:_2     含む：目安太線ノッチ　########
i <- 0
j <- 0
k <- 0

for (i in 1:111) {
    #for (j in 1:13) {
    for (k in 1:5) {
        
        a2 <- i
        b2 <- j
        c2 <- k
        
        if ((a2 == 20)||(a2 == 40)||(a2 == 60)||(a2 == 80)||(a2 == 100)){
#            abclines3d(a2,y=-5,c2, a=diag(3), col="grey", lwd=2)       ## x,y,z: Coordinates of points through which each line passes.
                abclines3d(a2,y=14,c2, a=diag(3), col="grey", lwd=2)     ## -1は線を消すため;14は奥に縦線
            next
        }
        
#        abclines3d(a2,y=-5,c2, a=diag(3), col="gray")      ## x,y,z: Coordinates of points through which each line passes.
            abclines3d(a2,y=14,c2, a=diag(3), col="gray")        ## -1は線を消すため;14は奥に縦線
        
    }
    #}
}
#####

#rgl.material(texenvmap = TRUE)


#grid3d(side = "x-", col = "gray", lwd =1, lty = 1)
#grid3d(side = "y+", col = "gray", lwd =1, lty = 1)
#grid3d(side = "z-", col = "gray", lwd =1, lty = 1)

# KzMatrix1 <- read.table("KzMatrix1.txt")
# rgl.viewpoint(userMatrix = KzMatrix1)

FileNameId_snapshot <- paste(DataName, ".png", sep = "")
png(file=FileNameId_snapshot, width=1667, height= 1207, bg = "transparent")          ## The resolution of Png was set:: 160223
rgl.snapshot(FileNameId_snapshot, fmt = "png", top = TRUE)

#FileNameId_snapshot_png2 <- paste(DataName, "_2.png", sep = "")
#png(file=FileNameId_snapshot_png2, width=1667, height= 1207, bg = "transparent")          ## The resolution of Png was set:: 160223
#snapshot3d(FileNameId_snapshot_png2)

#FileNameId_postscript_pdf <- paste(DataName, ".pdf", sep = "")
#rgl.postscript(FileNameId_postscript_pdf, fmt = "pdf", drawText = TRUE)        ## Pdf_File:: The size too huge:: ~250MB !!!  < abandon!!

########################
## KzMcP2にはH.264が重いのでscene3dを削除！！！！！！！！！！！！！！！！！！！！！！！！！！
#FileNameId_scene3d <- paste(DataName, "_scene3d.txt", sep = "")
#s <- scene3d()       # オブジェクトsの書き込み
#dput(s,file=FileNameId_scene3d)    # Kz140106test2.txtに書き込み
## !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# s2 <- dget("xxKz140106test2.txt")     # Get it
# plot3d(s2)          # もう一度開く

#writeWebGL()

######

# title3d(xlab="V",col="Black")
# title3d(ylab="D",col="Black")
# title3d(zlab="J",col="Black")

user1 <- par3d("userMatrix")
user1 <-rotate3d(user1, pi*0.1, 0, 0, 1)
user1 <-rotate3d(user1, -pi*0.1, 0, 1, 0)
user1 <-rotate3d(user1, -pi*0.1, 1, 0, 0)
rgl.viewpoint(userMatrix=user1)

########################

###  END of PipeLine  ###############################














