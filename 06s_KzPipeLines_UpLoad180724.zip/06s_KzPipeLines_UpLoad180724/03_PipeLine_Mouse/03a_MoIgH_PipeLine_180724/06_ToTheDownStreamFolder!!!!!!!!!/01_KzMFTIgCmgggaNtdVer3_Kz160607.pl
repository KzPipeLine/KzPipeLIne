#!/usr/bin/perl 

############################################
#
# 01_KzMFTIgCmgggaNtdVer3_Kz160607.pl
#
##  Run:  ##########################################
#
#   perl 01_KzMFTIgCmgggaNtdVer3_Kz160607.pl InputFileName OutputFileSuffix
#
#   (Ex. perl KzMFTIgCmggNtd_Kz1507072.pl 1.GAC.454Reads_Amplicons_20130904.fna_156 Test70712)
#
#   OutPuts are 1) OutputFileSuffix_KzMfIgM
#               2) OutputFileSuffix_KzMfIgG1
#               3) OutputFileSuffix_KzMfIgG2a
#               4) OutputFileSuffix_KzMfIgG3
#               5) OutputFileSuffix_KzMfIgA
#
###########################################################
#
#
#   Ver3    160607  IgG3, IgAを加えた
#
#   Ver2    150929  IgG1のCH1について、塩基置換の多型があった！！！！！！！！！　これを考慮に入れる
#   KTTPPSV:
#   AAAACAACACCCCCATCAGTC
#   GACTGATGGGGGTGTTGTTTT
#
#
# This is a derivativr of KzMFTIgCmggPOff.pl.
# This is for finding Nuclrotide (Ntd) IgC-signiture of IgM, IgG1, IgG2a, at once
# and output Ntd-seq, in each separate subfiles
# Output is mfasta file
#
# Design #####################################
# 	Get the entry one by one from multi-fasta
#	> Hand the dna sequence
#	> Find the Ntd_IgC-igniture that is given.
#	> Output the entry comment and the  Ntd sequence in mfasta format
#		file with the additional info such as the sequence length etc.
# IgC-signature ------------------------------
#	IgM   : SQSFPNV
#	IgG1  : KTTPPSV ..YPLA.. PGSAAQT
#	IgG2a : KTTAPSV ..YPLA.. PVCGDTT
# ------------------------------------------------
#
#   IgM
#   SQSFPNV:
#   AGTCAGTCCTTCCCAAATGTC
#   GACATTTGGGAAGGACTGACT
#   IgG1
#   KTTPPSV:
#   AAAACGACACCCCCATCTGTC
#   GACAGATGGGGGTGTCGTTTT
#   KTTPPSV:    IgG1の多型
#   AAAACAACACCCCCATCAGTC
#   GACTGATGGGGGTGTTGTTTT
#   IgG2a
#   KTTAPSV:
#   AAAACAACAGCCCCATCGGTC
#   GACCGATGGGGCTGTTGTTTT
#
#   1) 3'-IgA_CH1::DPVIIGC
#   Anti::AGCCGATTATCACGGGATCAC
#   Sens::GTGATCCCGTGATAATCGGCT
#
#   2) 3'-IgG3_CH1::PLVPGCS
#   Anti::CTGCAGCCAGGGACCAAGGGA
#   Sens::TCCCTTGGTCCCTGGCTGCAG
#
################
#  ** Completion:
###############################################################


use strict;
use warnings;

# From SubrDnaTranslLongAa
#
#use lib '/users/ohnishik/KzModules';   	# BeginPerlBioinfo.pm is there
#use BeginPerlBioinfo;			#see Chapter 6 about this module

# Initialize valiables

my ($output,$comment,$LongestLength,$Sequence,$LongestAaSeq,$AaLong,$LongAaSeq,$AaFragment,$LongestSeq);
my ($FrSeq, $LongestAaFrame, $i2, $target1, $target2, $target3, $target4, $target5, $search_string, $IgCFrame);
my ($output1, $output2, $output3, $output4, $output5);


my ($Ig);		# Ig class

my ($IgC1s);		# IgC_signature_Ntd: IgM_sens
my ($IgC1r);		# IgC_signature_Ntd: IgM_reverse

my ($IgC2s);		# IgC_signature_Ntd: IgG1_sens
my ($IgC2r);		# IgC_signature_Ntd: IgG1_reverse
my ($IgC2ps);		# IgC_signature_Ntd: IgG1_sens      多型
my ($IgC2pr);		# IgC_signature_Ntd: IgG1_reverse   多型

my ($IgC3s);		# IgC_signature_Ntd: IgG2a_sens
my ($IgC3r);		# IgC_signature_Ntd: IgG2a_reverse

my ($IgC4s);		# IgC_signature_Ntd: IgG3_sens
my ($IgC4r);		# IgC_signature_Ntd: IgG3_reverse

my ($IgC5s);		# IgC_signature_Ntd: IgA_sens
my ($IgC5r);		# IgC_signature_Ntd: IgA_reverse

my ($target1s);
my ($target1r);

my ($target2s);
my ($target2r);
my ($target2ps);
my ($target2pr);

my ($target3s);
my ($target3r);

my ($target4s);
my ($target4r);

my ($target5s);
my ($target5r);

my ($IgChit);
my ($IgChit2);
my ($LengthLongAa);
my ($IgCAaSeq);
my ($AaLength);


# Define Ig-signature (IgC)
	$IgC1s="AGTCAGTCCTTCCCAAATGTC";
	$IgC1r="GACATTTGGGAAGGACTGACT";

	$IgC2s="AAAACGACACCCCCATCTGTC";
	$IgC2r="GACAGATGGGGGTGTCGTTTT";
    $IgC2ps="AAAACAACACCCCCATCAGTC";
    $IgC2pr="GACTGATGGGGGTGTTGTTTT";

	$IgC3s="AAAACAACAGCCCCATCGGTC";
	$IgC3r="GACCGATGGGGCTGTTGTTTT";

    $IgC4s="GTGATCCCGTGATAATCGGCT";
    $IgC4r="AGCCGATTATCACGGGATCAC";

    $IgC5s="TCCCTTGGTCCCTGGCTGCAG";
    $IgC5r="CTGCAGCCAGGGACCAAGGGA";

print "\n  >> IgC-signature will be: \n IgM = $IgC1s or $IgC1r \n IgG1 = $IgC2s or $IgC2r  \n IgG2a = $IgC3s or $IgC3r \n IgG3 = $IgC4s or $IgC4r \n IgA = $IgC5s or $IgC5r   \n\n";

# Define and open the Output file
#print "\n", " Output file name Suffix ? ", "\n";
#chomp ( $output = <STDIN>  );
#print "\n", " Output file name Suffix ? ", "\n";
chomp ( $output = $ARGV[1] );
#$output1 = $output.'_KzMfIgM.txt';
#$output2 = $output.'_KzMfIgG1.txt';
#$output3 = $output.'_KzMfIgG2a.txt';
#$output1 = $output.'_KzMfIgM';      ## 160312
#$output2 = $output.'_KzMfIgG1';
#$output3 = $output.'_KzMfIgG2a';
#$output4 = $output.'_KzMfIgG3';
#$output5 = $output.'_KzMfIgA';
$output1 = $output.'_KzMfIgM.txt';      ## 160607
$output2 = $output.'_KzMfIgG1.txt';
$output3 = $output.'_KzMfIgG2a.txt';
$output4 = $output.'_KzMfIgG3.txt';
$output5 = $output.'_KzMfIgA.txt';


open ( SUBFILE1, ">>$output1" ) or die "Cannnot open SubSeq1.fa", "\n";
open ( SUBFILE2, ">>$output2" ) or die "Cannnot open SubSeq2.fa", "\n";
open ( SUBFILE3, ">>$output3" ) or die "Cannnot open SubSeq3.fa", "\n";
open ( SUBFILE4, ">>$output4" ) or die "Cannnot open SubSeq3.fa", "\n";
open ( SUBFILE5, ">>$output5" ) or die "Cannnot open SubSeq3.fa", "\n";

open(MOM0,"$ARGV[0]"); 			# ！！！！これを行わないと、while(<>)だけでは２回読み込んでしまう！！！！！

##  LOG_FILE  ###############################

my ($DataNameId);
my ($output0);
my ($now);

use POSIX 'strftime';

$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print "\n",">> Started: $now", "\n";

$DataNameId = $ARGV[1];
$output0 = $DataNameId."_Log.txt";                                          # Set the name of Log_File: $output0
open ( SUBFILE0, ">>$output0" ) or die "Cannnot open SubSeq.fa", "\n";      # Open the Log_File

print SUBFILE0 "\n", "##  ", $output0, "  ## ";
print SUBFILE0 "\n", "! Started:: $now","\n";

###########################################################


## START: Get each entry one by one ##############################

my $hit = 0;
my @tmp = '';
my $dna = '';

my $read = 0;			# Total read number

my $IgChitNum1 = 0;		# The number of IgC_IgM-containing read
my $IgChitNum2 = 0;		# The number of IgC_IgG1-containing read
my $IgChitNum3 = 0;		# The number of IgC_IgG2a-containing read
my $IgChitNum4 = 0;		# The number of IgC_IgG3-containing read
my $IgChitNum5 = 0;		# The number of IgC_IgA-containing read

$IgChit = 0;			# IgC-containing read = 1

while (<MOM0>)  {
	chomp ( $_ );
	my $Reading = $_;
	
    #print "\n", "Reading = ", $Reading ;
    #print "\n", "Hit = ", $hit ;
	
	if ( $_ =~ /^>/ ) {
        #print "\n", "read = ", $read, "\n";

		
		# The beging of the entry
		if ( $hit == 0 ) {
			$comment = $_;
            #print "\n","\n", "Comment = ", $comment;

			$hit = 1;
			
			$IgChit = 0;
			@tmp = '';
			$dna = '';
            
            next;

		} elsif ( $hit == 1 ) {
            #$comment = $_;             ## ここで代入すると$dnaを一つずれてしまう！！！＞最後にまわす！！
            $read++;
			$dna = join "", @tmp;				# join the sequence lines
			$dna =~ tr/A-Z//cd;   				# remove non-alphabet 
			$dna =~ tr/ATGC//cd;                            # remove non-ATGC > get $dna ready
            print "\n", "read = ", $read;
            #print "\n", '$dna = ', $dna;		# test
            #print "\n","Comment = ", $comment,"\n",;    # test; Is this match with above $dna??
            
			###	Go to the subroutine SubrDnaTranslIgC passing $dna
			my ($IgChit) = &IgCNtdFrg ($dna);
			######
			
			print "\t","IgChit = ", $IgChit,"\n";
			
			if ($IgChit == 1){
				$IgChitNum1++;

                print SUBFILE1 "$comment\n";
                print SUBFILE1 "$dna\n";

				@tmp = '';
				$dna = '';

			} elsif ($IgChit == 2){
				$IgChitNum2++;

                print SUBFILE2 "$comment\n";
                print SUBFILE2 "$dna\n";
				
				@tmp = '';
				$dna = '';
				
			} elsif ($IgChit == 3){
				$IgChitNum3++;

                print SUBFILE3 "$comment\n";
                print SUBFILE3 "$dna\n";
				
				@tmp = '';
				$dna = '';
				
            } elsif ($IgChit == 4){
                $IgChitNum4++;
                
                print SUBFILE4 "$comment\n";
                print SUBFILE4 "$dna\n";
                
                @tmp = '';
                $dna = '';
                
            } elsif ($IgChit == 5){
                $IgChitNum5++;
                
                print SUBFILE5 "$comment\n";
                print SUBFILE5 "$dna\n";
                
                @tmp = '';
                $dna = '';
                
            }



			@tmp = '';
			$dna = '';
            $comment = $_;
            next;
        }
        
        next;
    }
    
    ######	The contents of the entry hit; packing dna sequenes
    $Sequence = uc $_;				#UpperCase
    $Sequence =~ tr/A-Z//cd;		# delete characters non-alphabet
    #	print "\n", "Sequence = ", $Sequence;
    push @tmp, $Sequence;
    #print "\n", "Seq accumulation = ",$Sequence;
    
    next;
    
}

    ## The last entry!! ##############################
$read++;
print "\n", "read = ", $read;

$dna = join "", @tmp;				# join the sequence lines
$dna =~ tr/A-Z//cd;   				# remove non-alphabet
$dna =~ tr/ATGC//cd;                            # remove non-ATGC > get $dna ready
#print "\n", '$dna = ', $dna, "\n";		# test

###	Go to the subroutine SubrDnaTranslIgC passing $dna
#my ($IgChit) = &IgCNtdFrg ($dna);
$IgChit = &IgCNtdFrg ($dna);
######

print "\t", "IgChit = ", $IgChit;

if ($IgChit == 1){
    $IgChitNum1++;
    
				print SUBFILE1 "$comment\n";
				print SUBFILE1 "$dna\n";
    
    @tmp = '';
    $dna = '';
    
} elsif ($IgChit == 2){
    $IgChitNum2++;
    
				print SUBFILE2 "$comment\n";
				print SUBFILE2 "$dna\n";
    
    @tmp = '';
    $dna = '';
    
} elsif ($IgChit == 3){
    $IgChitNum3++;
    
				print SUBFILE3 "$comment\n";
				print SUBFILE3 "$dna\n";
    
    @tmp = '';
    $dna = '';
    
} elsif ($IgChit == 4){
    $IgChitNum4++;
    
				print SUBFILE4 "$comment\n";
				print SUBFILE4 "$dna\n";
    
    @tmp = '';
    $dna = '';
    
} elsif ($IgChit == 5){
    $IgChitNum5++;
    
				print SUBFILE5 "$comment\n";
				print SUBFILE5 "$dna\n";
    
    @tmp = '';      # ?? <<<<<<<<<<<<<<<<
    $dna = '';      # ?? <<<<<<<<<<<<
    
}



    ## The last entry done!! ##############################
close (MOM0);


close ( SUBFILE1 );
close ( SUBFILE2 );
close ( SUBFILE3 );
close ( SUBFILE4 );
close ( SUBFILE5 );

print "\n ***** Done ********************************** ";
print "\n >>> IgM_CH1-containing reads = $IgChitNum1 out of total reads $read <<< ";
print "\n >>> IgG1_CH1-containing reads = $IgChitNum2 out of total reads $read <<< ";
print "\n >>> IgG2a_CH1-containing reads = $IgChitNum3 out of total reads $read <<< ";
print "\n >>> IgG3_CH1-containing reads = $IgChitNum4 out of total reads $read <<< ";
print "\n >>> IgGA_CH1-containing reads = $IgChitNum5 out of total reads $read <<< ";
print "\n ********************************************* \n\n";


## Log file OutPut ################

print "\n\n\n";
print SUBFILE0 "\n  >> IgC-signature will be: \n IgM = $IgC1s or $IgC1r \n IgG1 = $IgC2s or $IgC2r \n IgG2a = $IgC3s or $IgC3r \n IgG3 = $IgC4s or $IgC4r \n IgA = $IgC5s or $IgC5r   \n\n";
print SUBFILE0 "\n ***** Done ********************************** ";
print SUBFILE0 "\n >>> IgM_CH1-containing reads = $IgChitNum1 out of total reads $read <<< ";
print SUBFILE0 "\n >>> IgG1_CH1-containing reads = $IgChitNum2 out of total reads $read <<< ";
print SUBFILE0 "\n >>> IgG2a_CH1-containing reads = $IgChitNum3 out of total reads $read <<< ";
print SUBFILE0 "\n >>> IgG3_CH1-containing reads = $IgChitNum4 out of total reads $read <<< ";
print SUBFILE0 "\n >>> IgA_CH1-containing reads = $IgChitNum5 out of total reads $read <<< ";
print SUBFILE0 "\n ********************************************* \n\n";
$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print $now, "\n\n";
print SUBFILE0 $now, "\n\n";

#############

close (SUBFILE0);


print "\007";
print "\007";
print "\007";

exit;

# END of the main program #########
######################################



###########################################################
#  Subroutines for DnaNtdSrchIgC
#######################################################

sub IgCNtdFrg {

# Initialize arguments and variables
$IgChit2 = 0;

# Search the IgC_Ntd
	$target1s = $IgC1s;
    $target1r = $IgC1r;
    
	$target2s = $IgC2s;
    $target2r = $IgC2r;
    $target2ps = $IgC2ps; # 多型
    $target2pr = $IgC2pr; # 多型
    
	$target3s = $IgC3s;
    $target3r = $IgC3r;
    
    $target4s = $IgC4s;
    $target4r = $IgC4r;
    
    $target5s = $IgC5s;
    $target5r = $IgC5r;

#	foreach $AaFragment (@AaFragment ) {		
#		$AaLength = length $AaFragment ;
##		print "\n","AaLength = ", $AaLength, " : ", $AaFragment;
#
#		$search_string = $AaFragment;
    
    #$search_string = @_;    #引数が配列の場合
    $search_string = $dna;    #引数が文字列の場合
    #print "search_string = ", $search_string,"\n";
		
		foreach my $i (0..length $search_string) {

			if ( $target1s eq substr( $search_string, $i, length $target1s))  {
				$IgChit2 = 1;
                return ($IgChit2);
                
            } elsif ( $target1r eq substr( $search_string, $i, length $target1r))  {
                $IgChit2 = 1;
                return ($IgChit2);

			} elsif ( $target2s eq substr( $search_string, $i, length $target2s))  {
				$IgChit2 = 2;
				return ($IgChit2);
				
            } elsif ( $target2r eq substr( $search_string, $i, length $target2r))  {
                $IgChit2 = 2;
                return ($IgChit2);
                
            } elsif ( $target2ps eq substr( $search_string, $i, length $target2s))  {
                $IgChit2 = 2;
                return ($IgChit2);
                
            } elsif ( $target2pr eq substr( $search_string, $i, length $target2r))  {
                $IgChit2 = 2;
                return ($IgChit2);
                
            } elsif ( $target3s eq substr( $search_string, $i, length $target3s))  {
                $IgChit2 = 3;
                return ($IgChit2);
                
            } elsif ( $target3r eq substr( $search_string, $i, length $target3r))  {
                $IgChit2 = 3;
                return ($IgChit2);
                
            } elsif ( $target4s eq substr( $search_string, $i, length $target4s))  {
                $IgChit2 = 4;
                return ($IgChit2);
                
            } elsif ( $target4r eq substr( $search_string, $i, length $target4r))  {
                $IgChit2 = 4;
                return ($IgChit2);
                
            } elsif ( $target5s eq substr( $search_string, $i, length $target5s))  {
                $IgChit2 = 5;
                return ($IgChit2);
                
            } elsif ( $target5r eq substr( $search_string, $i, length $target5r))  {
                $IgChit2 = 5;
                return ($IgChit2);
				
			} else {

			$IgChit2 = 0;

			}

		}	


	return ($IgChit2);


# End of Subrouteine 
}






