#!/usr/bin/perl -w

########################################################
#    06b_KzMFRmCmLn_160308.pl
#########################################
# The Original of KzMFRmCmLn.pl
# This is for Removing Comment Line
# Output to .txt File (Such as VhDhJh Output from KzVdjSort2.pl)
#
#   ## Run: ##########################
#
#   perl KzMFRmCmLn_140815.pl Kz140815_KnIgKEt1in20IgLTop100AAj_Sort.txt Kz140815_KnIgKEt1in20IgLTop100AAjSort_RmCmLn.txt
#
#
#   -- The number of entry(>) scanned: ( 20418 ) --
################################################
#
#       Ver4    160308      For MiSeq_IgBlast data
#
# Ver.1     130726
# Ver.2     131016
# Ver.3     140815
#
##############################################

# use strict;


my $numseq = 0;

#print " Output file name? ", "\n";
#chomp ( $output = <STDIN>  );
$output=$ARGV[1];
chomp ($output);
open ( SUBFILE, ">>$output" ) or die "Cannnot open SUBFILE", "\n";


###  LogFile  ###########################
#
##my ($DataNameId);
#my ($output1);
#my ($now);
#
#use POSIX 'strftime';
#
#$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
#print "\n",">> Started: $now", "\n";
#
#$output1 = $output."_Log.txt";  # Set the name of Log_File: $output0
#open ( SUBFILE0, ">>$output1" ) or die "Cannnot open SubSeq.fa", "\n";      # Open the Log_File
#
#print SUBFILE0 "\n", "##  ", $output1, "  ## ";
#print SUBFILE0 "\n", "! Started:: $now","\n";
#
###########################


## DATAFILEの限定；この操作をしないと、prescript.shのもとでは、ARGV[1],ARGV[2]も読み込んでしまう
my $InPutFile3 = $ARGV[0];
open(DATAFILE3, "< $InPutFile3") or die("error :$!");

while (<DATAFILE3>)  {
	chomp ( $_ );
	if ( $_ =~ /^>/ ) {

        next;
        
        #   print "$_", "\n";
        #   print SUBFILE "$_", "\n";

	} else {
        
        $numseq++;
        print "$numseq", "\n";
        
        #   print "$_", "\n";
        print SUBFILE "$_", "\n";

    }
}

close ( SUBFILE );

####  Log( )  ###
#$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
#print "\n",$now;
#
#print "\n"," -- Done( ):03_KzMFRmCmLn140219.pl -- The number of entry(>) scanned: ( $numseq ) -- ", "\n";
#print SUBFILE0 "\n"," -- Done( ):03_KzMFRmCmLn140219.pl -- The number of entry(>) scanned: ( $numseq ) -- ", "\n";
####
#
#print " -- The number of entry(>) scanned: ( $numseq ) -- ", "\n";
#print "\007";
#print "\007";
#print "\007";
#
#close (SUBFILE0);

# End
		
