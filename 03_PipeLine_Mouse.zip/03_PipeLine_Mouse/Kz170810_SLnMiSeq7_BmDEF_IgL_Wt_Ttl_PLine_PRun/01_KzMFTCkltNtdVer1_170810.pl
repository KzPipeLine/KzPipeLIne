#!/usr/bin/perl 

############################################
#
# 01_KzMFTCkltNtdVer1_170810.pl
#
##  Run:  ##########################################
#
#   perl 01_KzMFTCkltNtdVer1_170810.pl InputFileName OutputFileSuffix
#
#   (Ex. perl 01_KzMFTCkltNtdVer1_160305.pl WT-1_S22_L001_R1_001.fastq_Polished_RenTrmQflRcp_Test50.fna Test1603061)
#
#   OutPuts are 1) OutputFileSuffix_KzMfIgK.txt
#               2) OutputFileSuffix_KzMfIgL.txt
#               2) OutputFileSuffix_KzMfTrB.txt
#
###########################################################

#
# This is a derivativr of KzMFTIgCmggPOff.pl.
# This is for finding Nuclrotide (Ntd) IgC-signiture of IgKappa, IgLambda, TCR-Beta, at once
# and output Ntd-seq, in each separate subfiles
# Output is mfasta file
#
# Design #####################################
# 	Get the entry one by one from multi-fasta
#	> Hand the dna sequence
#	> Find the Ntd_IgC-igniture that is given.
#	> Output the entry comment and the  Ntd sequence in mfasta format
#		file with the additional info such as the sequence length etc.
# IgC-signature ------------------------------
#Kz160306_IgCSeqsForIgKLTrB_R1.txt
#
#KappaC_FwdPrimer::
#CTGTATCCATCTTCCCACCATCCAGTGAGC
#
#LambdaC1_FwdPrimer >> TGTTTCCACCTTCCTCTGAAGAGCTCGAG  ::OK (MiSeqTrimedR1の中にあり）
#LambdaC2_FwdPrimer >> TGTTTCCACCTTCCTCTGAGGAGCTCAAG  :: OK (MiSeqTrimedR1の中にあり）
#LambdaC3_FwdPrimer >> TGTTTCCACCTTCCCCTGAGGAGCTCCAG  :: OK (MiSeqTrimedR1の中にあり）
#LambdaC4_FwdPrimer >> TGTTCCCACCTTCCTCTGAAGAGCTCAAG  :: OK (MiSeqTrimedR1の中にあり）
#
#Kz160128_Mm_TcrbC_FwdPrimer_2.seq::
#CCACCCAAGGTCTCCTTGTTTGAGCCATC
# ------------------------------------------------
#
#   IgKappaC_Fwd
#   CTGTATCCATCTTCCCACCATCCAGTGAGC
#
#   IgLambdaC1_Fwd
#   TGTTTCCACCTTCCTCTGAAGAGCTCGAG
#   IgLambdaC2_Fwd
#   TGTTTCCACCTTCCTCTGAGGAGCTCAAG
#   IgLambdaC3_Fwd
#   TGTTTCCACCTTCCCCTGAGGAGCTCCAG
#   IgLambdaC4_Fwd
#   TGTTCCCACCTTCCTCTGAAGAGCTCAAG
#
#   TcrbC_Fwd
#   CCACCCAAGGTCTCCTTGTTTGAGCCATC
#
#
################
#  ** Completion:
###############################################################


use strict;
use warnings;

# From SubrDnaTranslLongAa
#
#use lib '/users/ohnishik/KzModules';   	# BeginPerlBioinfo.pm is there
#use BeginPerlBioinfo;			#see Chapter 6 about this module

# Initialize valiables

my ($output,$comment,$LongestLength,$Sequence,$LongestAaSeq,$AaLong,$LongAaSeq,$AaFragment,$LongestSeq);
my ($FrSeq, $LongestAaFrame, $i2, $target1, $target2, $target3, $search_string, $IgCFrame);
my ($output1, $output2, $output3);


my ($Ig);		# Ig class

################################################
#my ($IgC1s);		# IgC_signature_Ntd: IgM_sens
#my ($IgC1r);		# IgC_signature_Ntd: IgM_reverse
#
#my ($IgC2s);		# IgC_signature_Ntd: IgG1_sens
#my ($IgC2r);		# IgC_signature_Ntd: IgG1_reverse
#my ($IgC2ps);		# IgC_signature_Ntd: IgG1_sens      多型
#my ($IgC2pr);		# IgC_signature_Ntd: IgG1_reverse   多型
#
#my ($IgC3s);		# IgC_signature_Ntd: IgG2a_sens
#my ($IgC3r);		# IgC_signature_Ntd: IgG2a_reverse

my ($IgC_K);		# IgC_signature_Ntd: IgKappa_Fwd

my ($IgC_L1);		# IgC_signature_Ntd: IgLambda1_Fwd
my ($IgC_L2);		# IgC_signature_Ntd: IgLambda2_Fwd
my ($IgC_L3);		# IgC_signature_Ntd: IgLambda3_Fwd
my ($IgC_L4);		# IgC_signature_Ntd: IgLambda4_Fwd

my ($IgC_Tb);		# IgC_signature_Ntd: Tcrb_Fwd


###############


#####################################################
#my ($target1s);
#my ($target1r);
#
#my ($target2s);
#my ($target2r);
#my ($target2ps);
#my ($target2pr);
#
#my ($target3s);
#my ($target3r);

my ($target_K);

my ($target_L1);
my ($target_L2);
my ($target_L3);
my ($target_L4);

my ($target_Trb);






#########################




my ($IgChit);
my ($IgChit2);

my ($LengthLongAa);
my ($IgCAaSeq);
my ($AaLength);







############################################
# Define Ig-signature (IgC)
#	$IgC1s="AGTCAGTCCTTCCCAAATGTC";
#	$IgC1r="GACATTTGGGAAGGACTGACT";
#
#	$IgC2s="AAAACGACACCCCCATCTGTC";
#	$IgC2r="GACAGATGGGGGTGTCGTTTT";
#    $IgC2ps="AAAACAACACCCCCATCAGTC";
#    $IgC2pr="GACTGATGGGGGTGTTGTTTT";
#
#	$IgC3s="AAAACAACAGCCCCATCGGTC";
#	$IgC3r="GACCGATGGGGCTGTTGTTTT";

$IgC_K="CTGTATCCATCTTCCCACCATCCAGTGAGC";
$IgC_L1="TGTTTCCACCTTCCTCTGAAGAGCTCGAG";
$IgC_L2="TGTTTCCACCTTCCTCTGAGGAGCTCAAG";
$IgC_L3="TGTTTCCACCTTCCCCTGAGGAGCTCCAG";
$IgC_L4="TGTTCCCACCTTCCTCTGAAGAGCTCAAG";
$IgC_Tb="CCACCCAAGGTCTCCTTGTTTGAGCCATC";


########################################################################







#print "\n  >> IgC-signature will be: \n IgM = $IgC1s or $IgC1r \n IgG1 = $IgC2s or $IgC2r  \n IgG2a = $IgC3s or $IgC3r  \n\n";
print "\n  >> IgC-signature will be: \n IgK = $IgC_K \n IgL = $IgC_L1 or $IgC_L2 or $IgC_L3 or $IgC_L4  \n Trb = $IgC_Tb  \n\n";

# Define and open the Output file
#print "\n", " Output file name Suffix ? ", "\n";
#chomp ( $output = <STDIN>  );
#print "\n", " Output file name Suffix ? ", "\n";
chomp ( $output = $ARGV[1] );
$output1 = $output.'_KzMfIgK.txt';
$output2 = $output.'_KzMfIgL.txt';
$output3 = $output.'_KzMfIgTrb.txt';


open ( SUBFILE1, ">>$output1" ) or die "Cannnot open SubSeq1.fa", "\n";
open ( SUBFILE2, ">>$output2" ) or die "Cannnot open SubSeq2.fa", "\n";
open ( SUBFILE3, ">>$output3" ) or die "Cannnot open SubSeq3.fa", "\n";

open(MOM0,"$ARGV[0]"); 			# ！！！！これを行わないと、while(<>)だけでは２回読み込んでしまう！！！！！

##  LOG_FILE  ###############################

my ($DataNameId);
my ($output0);
my ($now);

use POSIX 'strftime';

$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print "\n",">> Started: $now", "\n";

$DataNameId = $ARGV[1];
$output0 = $DataNameId."_Log.txt";                                          # Set the name of Log_File: $output0
open ( SUBFILE0, ">>$output0" ) or die "Cannnot open SubSeq.fa", "\n";      # Open the Log_File

print SUBFILE0 "\n", "##  ", $output0, "  ## ";
print SUBFILE0 "\n", "! Started:: $now","\n";

###########################################################


## START: Get each entry one by one ##############################

my $hit = 0;
my @tmp = '';
my $dna = '';

my $read = 0;			# Total read number

my $IgChitNum1 = 0;		# The number of IgC_IgM-containing read
my $IgChitNum2 = 0;		# The number of IgC_IgG1-containing read
my $IgChitNum3 = 0;		# The number of IgC_IgG2a-containing read

$IgChit = 0;			# IgC-containing read = 1

while (<MOM0>)  {
	chomp ( $_ );
	my $Reading = $_;
	
    #print "\n", "Reading = ", $Reading ;
    #print "\n", "Hit = ", $hit ;
	
	if ( $_ =~ /^>/ ) {
        #print "\n", "read = ", $read, "\n";

		
		# The beging of the entry
		if ( $hit == 0 ) {
			$comment = $_;
            #print "\n","\n", "Comment = ", $comment;

			$hit = 1;
			
			$IgChit = 0;
			@tmp = '';
			$dna = '';
            
            next;

		} elsif ( $hit == 1 ) {
            #$comment = $_;             ## ここで代入すると$dnaを一つずれてしまう！！！＞最後にまわす！！
            $read++;
			$dna = join "", @tmp;				# join the sequence lines
			$dna =~ tr/A-Z//cd;   				# remove non-alphabet 
			$dna =~ tr/ATGC//cd;                            # remove non-ATGC > get $dna ready
            print "\n", "read = ", $read;
            #print "\n", '$dna = ', $dna;		# test
            #print "\n","Comment = ", $comment,"\n",;    # test; Is this match with above $dna??
            
			###	Go to the subroutine sub IgCNtdFrg passing $dna
			my ($IgChit) = &IgCNtdFrg ($dna);
			######
			
			print "\t","IgChit = ", $IgChit,"\n";
			
			if ($IgChit == 1){
				$IgChitNum1++;

                print SUBFILE1 "$comment\n";
                print SUBFILE1 "$dna\n";

				@tmp = '';
				$dna = '';

			} elsif ($IgChit == 2){
				$IgChitNum2++;

                print SUBFILE2 "$comment\n";
                print SUBFILE2 "$dna\n";
				
				@tmp = '';
				$dna = '';
				
			} elsif ($IgChit == 3){
				$IgChitNum3++;

                print SUBFILE3 "$comment\n";
                print SUBFILE3 "$dna\n";
				
				@tmp = '';
				$dna = '';
				
			}

			@tmp = '';
			$dna = '';
            $comment = $_;
            next;
        }
        
        next;
    }
    
    ######	The contents of the entry hit; packing dna sequenes
    $Sequence = uc $_;				#UpperCase
    $Sequence =~ tr/A-Z//cd;		# delete characters non-alphabet
    #	print "\n", "Sequence = ", $Sequence;
    push @tmp, $Sequence;
    #print "\n", "Seq accumulation = ",$Sequence;
    
    next;
    
}

    ## The last entry!! ##############################
$read++;
print "\n", "read = ", $read;

$dna = join "", @tmp;				# join the sequence lines
$dna =~ tr/A-Z//cd;   				# remove non-alphabet
$dna =~ tr/ATGC//cd;                            # remove non-ATGC > get $dna ready
#print "\n", '$dna = ', $dna, "\n";		# test

###	Go to the subroutine SubrDnaTranslIgC passing $dna
#my ($IgChit) = &IgCNtdFrg ($dna);
$IgChit = &IgCNtdFrg ($dna);
######

print "\t", "IgChit = ", $IgChit;

if ($IgChit == 1){
    $IgChitNum1++;
    
				print SUBFILE1 "$comment\n";
				print SUBFILE1 "$dna\n";
    
    @tmp = '';
    $dna = '';
    
} elsif ($IgChit == 2){
    $IgChitNum2++;
    
				print SUBFILE2 "$comment\n";
				print SUBFILE2 "$dna\n";
    
    @tmp = '';
    $dna = '';
    
} elsif ($IgChit == 3){
    $IgChitNum3++;
    
				print SUBFILE3 "$comment\n";
				print SUBFILE3 "$dna\n";
    
}

    ## The last entry done!! ##############################
close (MOM0);


close ( SUBFILE1 );
close ( SUBFILE2 );
close ( SUBFILE3 );

print "\n ***** Done ********************************** ";
print "\n >>> IgK_CH1-containing reads = $IgChitNum1 out of total reads $read <<< ";
print "\n >>> IgL_CH1-containing reads = $IgChitNum2 out of total reads $read <<< ";
print "\n >>> Trb_CH1-containing reads = $IgChitNum3 out of total reads $read <<< ";
print "\n ********************************************* \n\n";


## Log file OutPut ################

print "\n\n\n";
print SUBFILE0 "\n  >> IgC-signature will be: \n IgK = $IgC_K \n IgL = $IgC_L1 or $IgC_L2 or $IgC_L3 or $IgC_L4  \n Trb = $IgC_Tb  \n\n";
print SUBFILE0 "\n ***** Done ********************************** ";
print SUBFILE0 "\n >>> IgK_CH1-containing reads = $IgChitNum1 out of total reads $read <<< ";
print SUBFILE0 "\n >>> IgL_CH1-containing reads = $IgChitNum2 out of total reads $read <<< ";
print SUBFILE0 "\n >>> Trb_CH1-containing reads = $IgChitNum3 out of total reads $read <<< ";
print SUBFILE0 "\n ********************************************* \n\n";
$now = strftime "%Y/%m/%d %H:%M:%S", localtime;
print $now, "\n\n";
print SUBFILE0 $now, "\n\n";

#############

close (SUBFILE0);


print "\007";
print "\007";
print "\007";

exit;

# END of the main program #########
######################################



###########################################################
#  Subroutines for DnaNtdSrchIgC
#######################################################

sub IgCNtdFrg {

# Initialize arguments and variables
$IgChit2 = 0;

# Search the IgC_Ntd
#	$target1s = $IgC1s;
#    $target1r = $IgC1r;
#    
#	$target2s = $IgC2s;
#    $target2r = $IgC2r;
#    $target2ps = $IgC2ps; # 多型
#    $target2pr = $IgC2pr; # 多型
#    
#	$target3s = $IgC3s;
#    $target3r = $IgC3r;

#	foreach $AaFragment (@AaFragment ) {		
#		$AaLength = length $AaFragment ;
##		print "\n","AaLength = ", $AaLength, " : ", $AaFragment;
#
#		$search_string = $AaFragment;
    
    #$search_string = @_;    #引数が配列の場合
    $search_string = $dna;    #引数が文字列の場合
    #print "search_string = ", $search_string,"\n";
		
		foreach my $i (0..length $search_string) {

			if ( $IgC_K eq substr( $search_string, $i, length $IgC_K))  {
				$IgChit2 = 1;
                return ($IgChit2);
                
            } elsif ( $IgC_L1 eq substr( $search_string, $i, length $IgC_L1))  {
                $IgChit2 = 2;
                return ($IgChit2);
                
            } elsif ( $IgC_L2 eq substr( $search_string, $i, length $IgC_L2))  {
                $IgChit2 = 2;
                return ($IgChit2);
                
            } elsif ( $IgC_L3 eq substr( $search_string, $i, length $IgC_L3))  {
                $IgChit2 = 2;
                return ($IgChit2);
                
            } elsif ( $IgC_L4 eq substr( $search_string, $i, length $IgC_L4))  {
                $IgChit2 = 2;
                return ($IgChit2);
                
            } elsif ( $IgC_Tb eq substr( $search_string, $i, length $IgC_Tb))  {
                $IgChit2 = 3;
                return ($IgChit2);
#                
#            } elsif ( $target1r eq substr( $search_string, $i, length $target1r))  {
#                $IgChit2 = 1;
#                return ($IgChit2);
#
#			} elsif ( $IgC_L1 eq substr( $search_string, $i, length $IgC_L1))  {
#				$IgChit2 = 2;
#				return ($IgChit2);
#				
#            } elsif ( $target2r eq substr( $search_string, $i, length $target2r))  {
#                $IgChit2 = 2;
#                return ($IgChit2);
#                
#            } elsif ( $target2ps eq substr( $search_string, $i, length $target2s))  {
#                $IgChit2 = 2;
#                return ($IgChit2);
#                
#            } elsif ( $target2pr eq substr( $search_string, $i, length $target2r))  {
#                $IgChit2 = 2;
#                return ($IgChit2);
#                
#            } elsif ( $target3s eq substr( $search_string, $i, length $target3s))  {
#                $IgChit2 = 3;
#                return ($IgChit2);
#                
#            } elsif ( $target3r eq substr( $search_string, $i, length $target3r))  {
#                $IgChit2 = 3;
#                return ($IgChit2);
				
			} else {

			$IgChit2 = 0;

			}

		}	


	return ($IgChit2);


# End of Subrouteine 
}






