#!/bin/bash

#########################################################
##  00_2DView_MoIgL_Kz180406.sh
##
#####  Run:  ###########
##
##  $ . 00_2DView_MoIgL_Kz180406.sh
##
########################################
##
##  Ver1:   160308
##
##
##
##
####  Steps:  #################################
##
##  (0) Starting Data: MiSeqOutPut, Polished
##          Ex. WT-1_S22_L001_R1_001.fastq_Polished_RenTrmQflRcp.fna
##
##  (1) IgCkltNtd.pl
##
##  [[(2) RLTagFilter ]]
##
##  (3) UniRds_TtlUniHom
##
##  (4) IgBlastN_ProdRand_(ShmMtEq2)  << For IgK, IgL, TcrB
##
##  (5) After_IgBlast_1  #####  Perl: IgBlast_productive > V,(D),J_BestMatch_List > RmCmLn まで
##
##  (6) After_IgBlast_2  #####  R: RmCmLn > V(D)J_Matrix  まで
##
##
##
##
##
##
##
##
##
#######################################################################################


#!/bin/bash


## Start_line...........................

## Do_Loops ###### >> Done_Loops @ bottom below ##################

#for Para_4 in KO-D-mix_S34 KO-D-x1_S31     ## <<<<<<<<<<<<<<<<<<<<<<<< InPut  !!!!!!!!
for Para_4 in 00_Kz180406_MoIgL_Test     ##  <<<<<<<<<<<<<<<<<<<<<<<< InPut  !!!!!!!!
do
echo -e  "Para_4::"
echo $Para_4



## [0] Name of the Folder #####################

#FolderName="Kz170809_SLnMiSeq7_BmDEF_Wt"		##
FolderName=$Para_4
echo -e  "FolderName::"
echo -e $FolderName
cd ./$FolderName            # Folderに入る
##########################################################

##################
## InPutNames!!!!!!!!!!!!!!!!!!!!!!
## KO
#[1] Name of the Project

ProjectName=$FolderName		## <<<<<<<<<<<<<<<<<<<< Check !!
echo -e  "ProjectName::"
echo -e $ProjectName

#[2] Name of 1st InPutFile

InPutFile_1=$Para_4".fna"		## <<<<<<<<<<<<<<<<<<<<<<< Check !!
echo -e  "InPutFile_1::"
echo -e $InPutFile_1


############################
## Making2ndNames!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#[1] BigLogName
BigLogName="00a_"$ProjectName"_BigLog.txt"
echo -e  "BigLogName::"
echo -e $BigLogName





##################################
## Here Starts!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

echo -e "\n## "$ProjectName"_Started........." | tee -a  ./$BigLogName
date | tee -a  ./$BigLogName



##  OutName1を与える  #########

OutName1=$Para_4     ##  <<<<<<<<  !!!!!!!!!!!  (2) OutName1を与える <<<　自動でOK  <<<<<<<<<<<<
echo -e  "OutName1::"
echo $OutName1



##  $$(1)  #####

echo -e "\n(1) IgCkltNtd_Started: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

## (1) IgCmggNtd  #####　Ampliconの中のIgCmggNtd配列を持つものを抽出して、IgM,IgG1,IgG2cの3グループに分類

OutName=$OutName1
echo -e  "OutName::"
echo $OutName

perl ./01_KzMFTCkltNtdVer1_170810.pl ./$InPutFile_1 ./$OutName     ##  170810:: <<<<<< !!!!!!!!  (3)Data_Fileを指定 <<  自動　<<<<<<<<<<


#   OutPuts are 1) $OutName1_KzMfIgK.txt
#               2) $OutName1_KzMfIgL.txt
#               2) $OutName1_KzMfIgTrb.txt

################  Step(1) Done  ########################

echo -e "\n(1) IgCkltNtd_Done: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み
echo -e '\a'    # Beep
echo -e '\a'    # Beep





##  $$(4)  #####
echo -e "\n(4) IgBlast_Started: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

####  NNNEEEEWWWWWWWWWWWWWW !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##　(4-1) IgBlast  #####  (IgKをIgBlastにかける　　##############

#for i in K L Trb
for i in K
do
echo $i


#for k in Ttl Uni Hom
for k in Ttl
do
echo $k




## -queryにInPutFile:

InFile=$OutName1"_KzMfIg"$i".txt"           ## WithOut RL-Tag
echo $InFile



## OutPutFileName_Blast
OutName=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlast.txt"          ## WithOut RL-Tag
echo $OutName


## OutPutFileName_Blast>Excel
OutName2=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastExcel.txt"        ## WithOut RL-Tag
echo $OutName2




##  IgBlast !!!!!!!!  For Kappa
igblastn -germline_db_V $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIgkV_NtdDb.txt -germline_db_J $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIgkJ_NtdDb.txt -germline_db_D $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghD_NtdDb.txt -organism mouse -domain_system imgt -query ./$InFile -auxiliary_data $IGDATA/optional_file/mouse_gl.aux -show_translation -outfmt 7 >> ./$OutName



##  IgBlastOut to ExcelFile
perl ./04c_KzIgBlast_N_ProductiveRandom_OutToExcel_ArgvRun_MiSeq_VJ_160307.pl ./$OutName ./$OutName2


##
#   OutPuts are 1) $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastExcel.txt"
##

echo -e '\a'        #Beep



done                    #for k
#done                    #for j
done                    #for i


##
################  Step(4-1) Done  #############################################################

echo -e "\n(4-1) IgBlast_Done: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep


#########################################
##　(4-2) IgBlast  #####  (IgLをIgBlastにかける　　##############

#for i in K L Trb
for i in L
do
echo $i


#for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
#do
#echo $j


#for k in Ttl Uni Hom
for k in Ttl
do
echo $k




## -queryにInPutFile:

InFile=$OutName1"_KzMfIg"$i".txt"           ## 170810:: WithOut RL-Tag
echo $InFile


## OutPutFileName_Blast

OutName=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlast.txt"          ## WithOut RL-Tag
echo $OutName


## OutPutFileName_Blast>Excel

OutName2=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastExcel.txt"        ## WithOut RL-Tag
echo $OutName2




##  IgBlast !!!!!!!!  For Lambda
igblastn -germline_db_V $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIglV_NtdDb.txt -germline_db_J $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIglJ_NtdDb.txt -germline_db_D $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghD_NtdDb.txt -organism mouse -domain_system imgt -query ./$InFile -auxiliary_data $IGDATA/optional_file/mouse_gl.aux -show_translation -outfmt 7 >> ./$OutName



##  IgBlastOut to ExcelFile
perl ./04c_KzIgBlast_N_ProductiveRandom_OutToExcel_ArgvRun_MiSeq_VJ_160307.pl ./$OutName ./$OutName2


##
#   OutPuts are 1) $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastExcel.txt"
##

echo -e '\a'        #Beep



done                    #for k
#done                    #for j
done                    #for i


##
################  Step(4-1) Done  #############################################################

echo -e "\n(4-2) IgBlast_Done: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep




###########################################################
###　(4-3) IgBlast  #####  (TrbをIgBlastにかける　　##############
#
##for i in K L Trb
#for i in Trb
#do
#echo $i
#
#
##for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
##do
##echo $j
#
#
##for k in Ttl Uni Hom
#for k in Ttl
#do
#echo $k
#
#
#
#
### -queryにInPutFile:
#
#InFile=$OutName1"_KzMfIg"$i".txt"           ## 170810:: WithOut RL-Tag
#echo $InFile
#
#
### OutPutFileName_Blast
#
#OutName=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlast.txt"          ## WithOut RL-Tag
#echo $OutName
#
#
### OutPutFileName_Blast>Excel
#
#OutName2=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastExcel.txt"        ## WithOut RL-Tag
#echo $OutName2
#
#
#
#
###  IgBlast !!!!!!!!  For Trb
### b).  To query one or more mouse T cell receptor sequences (contained in myseq) against imgt mouse germline gene database:
##./igblastn -germline_db_V imgt_tcr_db_v -germline_db_J imgt_tcr_db_j -germline_db_D imgt_tcr_db -organism mouse -domain_system imgt -query myseq -ig_seqtype TCR -auxiliary_data optional_file/mouse_gl.aux -show_translation -outfmt
#
##igblastn -germline_db_V $IGDATA/ImgtMouseTcr_ntd_Kz160306/Kz160306_ImgtMouseTcrbV_ntd_NtdDb.txt -germline_db_J $IGDATA/ImgtMouseTcr_ntd_Kz160306/Kz160306_ImgtMouseTcrbJ_ntd_NtdDb.txt -germline_db_D $IGDATA/ImgtMouseTcr_ntd_Kz160306/Kz160306_ImgtMouseTcrbD_ntd_NtdDb.txt -organism mouse -domain_system imgt -query ./$InFile -auxiliary_data $IGDATA/optional_file/mouse_gl.aux -show_translation -outfmt 7 >> ./$OutName
#igblastn -germline_db_V $IGDATA/ImgtMouseTcr_ntd_Kz160306/Kz160306_ImgtMouseTcrbV_ntd_NtdDb.txt -germline_db_J $IGDATA/ImgtMouseTcr_ntd_Kz160306/Kz160306_ImgtMouseTcrbJ_ntd_NtdDb.txt -germline_db_D $IGDATA/ImgtMouseTcr_ntd_Kz160306/Kz160306_ImgtMouseTcrbD_ntd_NtdDb.txt -organism mouse -domain_system imgt -query ./$InFile -ig_seqtype TCR -auxiliary_data $IGDATA/optional_file/mouse_gl.aux -show_translation -outfmt 7 >> ./$OutName     ## -ig_seqtype TCR < added
#
#
###  IgBlastOut to ExcelFile
#perl ./04b_KzIgBlast_N_ProductiveRandom_OutToExcel_ArgvRun_MiSeq_VDJ_160307.pl ./$OutName ./$OutName2
#
#
###
##   OutPuts are 1) $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastExcel.txt"
###
#
#echo -e '\a'        #Beep



done                    #for k
#done                    #for j
done                    #for i


##
################  Step(4-3) Done  #############################################################

echo -e "\n(4-3) IgBlast_Done: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep








##  $$(5)  ############
echo -e "\n(5) IgKL_VjSort_Started: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

##　(5) IgKL_VjSort  #####  Blastの結果について（IgK, IgLをマージして）、V、Jを分類する　　##############
##  (5-1)   Kappa_readsとLambda_readsをjoin,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
## For Kappa and Lambda,,,,,,,,,,,,,
#for k in Ttl Uni Hom
for k in Ttl
do
echo $k

## InPutFile_IgK:
InFile_K=$OutName1"_KzMfIgK_"$k"Rds_IgBlastExcel.txt"
echo $InFile_K

## InPutFile_IgL:
InFile_L=$OutName1"_KzMfIgL_"$k"Rds_IgBlastExcel.txt"
echo $InFile_L

## OutPutFileName_IgKlMerged
OutName3=$OutName1"_KzMfIgKLm_"$k"Rds_IgBlastExcel_KlMerged.txt"
echo $OutName3

## Merge  !!!!!!!!!!!!!!!!!!!
cat $InFile_K >> $OutName3
cat $InFile_L >> $OutName3

#####  (5-1) Done ....................................................


##  (5-2)   K-L_Merged_fileをMfastaファイルにする　　## Blast_Excel_File to MFasta_file ,,,,,,,,,,,,,,,,,,,,,
OutName4=$OutName3"_mfasta.txt"
echo $OutName4
perl ./KzIgBlastExcelToMfasta_Argv_160308.pl $OutName3 $OutName4

#####  (5-2) Done ...............................................................


##  (5-3)   XX_Merged_mfastaについて、IGKV, IGKJ, IGLV, IGLJを同定して番号を割り当てる,,,,,,,,,,,,,,,,,,,,,,,,,,,
OutName5=$OutName4"_IgKlSorted.txt"
echo $OutName5
perl ./06_KzIgKLVjSort_MiSeq_160308.pl $OutName4 $OutName5

#####  (5-3) Done ...............................................................


##  (5-3b)   XX_Merged_mfastaについて、IGKV, IGKJ, IGLV, IGLJを同定して番号を割り当てる,,,,,,,,,,,,,,,,,,,,,,,,,,,
OutName6=$OutName5"_RmCmLn.txt"
echo $OutName6
perl ./06b_KzMFRmCmLn_160308.pl $OutName5 $OutName6

#####  (5-3b) Done ...............................................................

##  Step (5) Done  ##############################################################################
echo -e "\n(5) IgKL_VjSort_Done: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep





##  $$(6) ############## R_Prescription
echo -e "\n(6) IgKlVj_CountNormalize_Started: " >> ./$BigLogName
date >> ./$BigLogName
##  (6)   XX_IgKlSorted_RmCmLnについて各IGKV, IGKJ, IGLV, IGLJを集計して、Normalizaする,,,,,,,,,,,,,,,,,,,,,,,,,,,
## InPutFile:
InFile=$OutName6
echo $InFile
## OutPutFileNameSuffices_R
OutName=$OutName6"_IgKlCount.txt"         ## WithOut RL-Tag
echo $OutName

R --vanilla --slave --args $InFile $OutName << EOF  ##################

args <- commandArgs(trailingOnly = T) # コマンドライン引数を読み込む

library(beepr)
beep(2)


if(length(args) != 2) { # 引数の数をチェックする。引数が2つでない場合は...
write("Error: commandline arguments for <infile> <outfile> are required", stderr())
# エラーメッセージを表示して...
q() # 終了する。
}

print (args[1])
print (args[2])

infile <- args[1] # 1番目の引数を入力ファイル名として代入する
print(infile)
outfile <- args[2] # 2番目の引数を出力ファイル名として代入する。
print(outfile)

Data1 <- read.table(infile)
DataName <- outfile

source("07_KzR_IgKLMatrix140828.R")


EOF
################  Step(6) Done  ##############################################################
echo -e "\n(6) IgKlVj_CountNormalize_Done: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep





done        #for k



##
################  All Done  #############################################################

echo -e "\n(5) IgKL_VjSort_Done: " >> ./$BigLogName
date >> ./$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep




## Here Bottom !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
## Done_Loop #################################

## !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
cd ../      #  一つ上の、.sh_Dirに戻る！  ##!!!!!!!!!!!!!!!!!!!!!!!  ########  !!!!!!!!!!!!!!!!!!!  ##
##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


#done        #for Para_1


#done        #for Para_2
#done        #for Para_3

done        #for Para_4

##################

echo -e '\a'        #Beep
echo -e '\a'        #Beep
echo -e '\a'        #Beep

## All Done ######################################


