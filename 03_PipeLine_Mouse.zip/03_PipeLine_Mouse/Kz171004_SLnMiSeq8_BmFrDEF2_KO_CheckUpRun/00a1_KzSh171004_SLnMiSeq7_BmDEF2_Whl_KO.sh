#!/bin/bash

#############################################
##
##  00a1_KzSh171004_SLnMiSeq7_BmDEF2_Whl_KO.sh
##
####  Run:  ###############
##
##  $ . 00a1_KzSh171004_SLnMiSeq7_BmDEF2_Whl_KO.sh
##
########################################
##
##  Ver1:   150714
##  Ver2:   150730
##  Ver3:   160607  IgG3, IgA added
##
####  Steps:  #################################
##
##  (0) Starting Data: Amplicon.fna
##
##  (1) IgCmggNtd
##
##  [(2) RLTagFilter ]
##
##  (3) UniRds_TtlUniHom
##
##  (4) IgBlastN_ProdRand_(ShmMtEq2)
##
##  (5) After_IgBlast_1  #####  Perl: IgBlast_productive > V,D,J_BestMatch_List > RmCmLn まで
##
##  (6) After_IgBlast_2  #####  R: RmCmLn > VDJ_Matrix > Rgl まで
##
##
##
##
##
##
####  Preparations::  ############################################
##
##  (1) BigLogの名前を更新        << Find/Replace :: All
##
##  (2) OutName1を与える  >> 自動！！
##
##  (3) Data_Fileを指定   >> 自動！！
##
##  [[[[[(4) Step2::RL-Tagを指定すること！！　 << Line_88 of 02b_KzMfRLTagFilterLoopArgv_150714.pl
##  [[[[[(4') 本プログラムの for j in xxx　でRLの番号をかえること！！           Lines:: 210 276 375 459
##
##  !!! (6) Rプログラム：06_Kz160225R_CompletePipeLine_Vdj3R_Rgl_OmitScene3d_PngRes2.R
##          >>　各最下層フォルダ（各データと同じdir)にコピーしておく事！！！！！！
##
##  <<<<<<<<<<<<<<<<<<<<<<<<<
##      下記は必要なし
##  (5) 最後尾：
##      Around 543  !!!
##      cd ./00_PipeLineCorePrograms_Kz150820      #  一つ下の、Program_Dirに戻る！ <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  !!!!!!!!!!!
##      Around 569  !!!
##      cd ../../      #  ２つ上の、BigLogの有るDirにもどる
##
##
##
#######################################################################################


#!/bin/bash


## Start_line...........................

## Do_Loops ###### >> Done_Loops @ bottom below ##################

# (0) BM or T2
#for Para_4 in boostD7    ## OR naive ???????????????????????????????????????????????
#for Para_4 in KO-D-mix_S34 KO-D-x1_S31     ## CheckUpRun ???????????????????????????????????????????????
for Para_4 in Kz171004_SLnMiSeq8_KO-1_S26_L001_R1_001_Num__Polished_RenTrmQflRcp Kz171004_SLnMiSeq8_KO-2_S27_L001_R1_001_Num__Polished_RenTrmQflRcp Kz171004_SLnMiSeq8_KO-3_S28_L001_R1_001_Num__Polished_RenTrmQflRcp Kz171004_SLnMiSeq8_KO-4_S29_L001_R1_001_Num__Polished_RenTrmQflRcp     ## PerformanceRun ???????????????????????????????????????????????
do
echo -e  "Para_4::"
echo $Para_4



## (1) KO
#for Para_3 in KO    ## OR WT ???????????????????????????????????????????????
#do
#echo $Para_3
#
##for Para_2 in R1 R2
#for Para_2 in R1
#do
#echo $Para_2
#
##for Para_1 in 1 2 3 4 5
#for Para_1 in 6 7 8 9
#do
#echo $Para_1
#Para_1w=`expr $Para_1 + 31`
#echo $Para_1w

## (2) WT           ## Change to InPutNames for WT !!!!!!!!!!!!!!!!!!!!!!!!
#for Para_3 in WT
#do
#echo $Para_3
#
#for Para_2 in R1 R2
#do
#echo $Para_2
#
#for Para_1 in 1 2 3 4 5
#Para_1w=`expr $Para_1 + 5`
#do
#echo $Para_1
#echo $Para_1w

################################################

## [0] Name of the Folder #####################
#FolderName=$Para_3"-"$Para_1"_S"$Para_1"_L001_"$Para_2"_001"		##
#FolderName=$Para_4"-"$Para_3"-m"$Para_1"_S"$Para_1w"_L001_"$Para_2"_001"		##
FolderName="Kz171004_SLnMiSeq8_BmDEF2_KO"		##
echo -e  "FolderName::"
echo -e $FolderName
cd ./$FolderName            # Folderに入る
##########################################################

##################
## InPutNames!!!!!!!!!!!!!!!!!!!!!!
## KO
#[1] Name of the Project
#ProjectName="Kz170809_SLnMiSeq6_"$FolderName		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
ProjectName=$FolderName		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
echo -e  "ProjectName::"
echo -e $ProjectName

#[2] Name of 1st InPutFile
#InPutFile_1="KO-1_S1_L001_R1_001.fastq"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#InPutFile_1=$FolderName".fastq_Polished_RenTrmQflRcp.fna"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
InPutFile_1=$Para_4".fna"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
echo -e  "InPutFile_1::"
echo -e $InPutFile_1

##[3] PreFix of Reads
##PreFixRead_1="Kz160224_SLnMiSeq1_KO1_R1_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#PreFixRead_1=$ProjectName"_"$InPutFile_1"_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "PreFixRead_1::"
#echo -e $PreFixRead_1
#
##[4] PreFix of OutPutFiles
##PreFixOut_1="Kz160224_SLnMiSeq1_KO1_R1"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#PreFixOut_1=$InPutFile_1"_Polished"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "PreFixOut_1::"
#echo -e $PreFixOut_1

### WT
##[1] Name of the Project
#ProjectName="Kz160224_SLnMiSeq1"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "ProjectName::"
#echo -e $ProjectName
#
##[2] Name of 1st InPutFile
##InPutFile_1="KO-1_S1_L001_R1_001.fastq"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#InPutFile_1=$Para_3"-"Para_1"_S"$Para_1w"_L001_"$Para_2"_001.fastq"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "InPutFile_1::"
#echo -e $InPutFile_1
#
##[3] PreFix of Reads
##PreFixRead_1="Kz160224_SLnMiSeq1_KO1_R1_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#PreFixRead_1=$ProjectName"_"$InPutFile_1"_Num_"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "PreFixRead_1::"
#echo -e $PreFixRead_1
#
##[4] PreFix of OutPutFiles
##PreFixOut_1="Kz160224_SLnMiSeq1_KO1_R1"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#PreFixOut_1=$InPutFile_1"_Polished"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Input!!
#echo -e  "PreFixOut_1::"
#echo -e $PreFixOut_1



############################
## Making2ndNames!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#[1] BigLogName
BigLogName="00a_"$ProjectName"_BigLog.txt"
echo -e  "BigLogName::"
echo -e $BigLogName

##[2] OutFileName_Renamed
#OutFileRen=$PreFixOut_1"_Ren"
#echo -e "## OutFileRenamed:: "$OutFileRen 2>&1 | tee -a  ../$BigLogName
#
##[3] OutFileName_Renamed > QualityTrimmed
#OutFileRenTrm=$PreFixOut_1"_RenTrm"
#echo -e "## OutFileRenamedTrimmed:: "$OutFileRenTrm 2>&1 | tee -a  ../$BigLogName
#
##[4] OutFileName_RenamedTrimmed > QualtyFiltered
#OutFileRenTrmQfl=$PreFixOut_1"_RenTrmQfl"
#echo -e "## OutFileRenamedTrimmedQFiltered:: "$OutFileRenTrmQfl 2>&1 | tee -a  ../$BigLogName
#
##[5] OutFileName_RenamedTrimmedQFiltered > ReverseComplement
#OutFileRenTrmQflRcp=$PreFixOut_1"_RenTrmQflRcp"
#echo -e "## OutFileRenamedTrimmedQFilteredRComplement:: "$OutFileRenTrmQflRcp 2>&1 | tee -a  ../$BigLogName
#
##[6] OutFileName_RenamedTrimmedQFilteredRComplement > fasta
#OutFileRenTrmQflRcpFna=$PreFixOut_1"_RenTrmQflRcp.fna"
#echo -e "## OutFileRenamedTrimmedQFilteredRComplementFastaNA:: "$OutFileRenTrmQflRcpFna 2>&1 | tee -a  ../$BigLogName






##################################
## Here Starts!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

echo -e "\n## "$ProjectName"_Started........." | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName







##  OutName1を与える  #########
#OutName1=$ProjectName     ##  <<<<<<<<  !!!!!!!!!!!  (2) OutName1を与える <<<　自動でOK  <<<<<<<<<<<<<<<<<<<<<<
OutName1=$Para_4     ##  <<<<<<<<  !!!!!!!!!!!  (2) OutName1を与える <<<　自動でOK  <<<<<<<<<<<<<<<<<<<<<<
echo -e  "OutName1::"
echo $OutName1








##  $$(1)  #####

echo -e "\n(1) IgCmggNtd_Started: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

## (1) IgCmggNtd  #####　Ampliconの中のIgCmggNtd配列を持つものを抽出して、IgM,IgG1,IgG2cの3グループに分類
## (1) IgCmggNtd  #####　Ampliconの中のIgCmggNtd配列を持つものを抽出して、IgM,IgG1,IgG2c,IgG3,IgAの3グループに分類

OutName=$OutName1
echo -e  "OutName::"
echo $OutName


perl ~/KzPipeLines/01_KzMFTIgCmgggaNtdVer3_Kz160607.pl ./$InPutFile_1 ./$OutName     ##  <<<<<< !!!!!!!!  (3) Data_Fileを指定 <<<<<<<<<<

#   OutPuts are 1) $OutName1_KzMfIgM.txt
#               2) $OutName1_KzMfIgG1.txt
#               3) $OutName1_KzMfIgG2a.txt
#               4) $OutName1_KzMfIgG3.txt
#               5) $OutName1_KzMfIgA.txt

################  Step(1) Done  ########################

echo -e "\n(1) IgCmggNtd_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
echo -e '\a'    # Beep
echo -e '\a'    # Beep
















## [[[[[[[[[[[[[[[[[[[[[[
###  $$(2)  #####
#
#echo -e "\n(1) RLTagFilter_Started: " >> ../$BigLogName
#date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
#
#
###　(2) RLTagFilter  #####  IgM,IgG1,IgG2c各グループの中をRL1,RL2,RL3,RL4,RL5に分類  ##############
#
## IgM
#
#InFile=$OutName1"_KzMfIgM.txt"
#echo $InFile
#OutName=$OutName1"_KzMfIgM"
#echo $OutName
#
#perl 02_KzMfRLTagFilterLoopArgv_150714.pl ../$InFile ../$OutName
#
#echo -e '\a'    # Beep
#echo -e '\a'    # Beep
#
##   OutPuts are 1) $OutName1_KzMfIgM_RL1.txt
##               2) $OutName1_KzMfIgM_RL2.txt
##               3) $OutName1_KzMfIgM_RL3.txt
##               4) $OutName1_KzMfIgM_RL4.txt
##               5) $OutName1_KzMfIgM_RL5.txt
#
## IgG1
#
#InFile=$OutName1"_KzMfIgG1.txt"
#echo $InFile
#OutName=$OutName1"_KzMfIgG1"
#echo $OutName
#
#perl 02_KzMfRLTagFilterLoopArgv_150714.pl ../$InFile ../$OutName
#
#echo -e '\a'    # Beep
#echo -e '\a'    # Beep
#
##   OutPuts are 1) $OutName1_KzMfIgG1_RL1.txt
##               2) $OutName1_KzMfIgG1_RL2.txt
##               3) $OutName1_KzMfIgG1_RL3.txt
##               4) $OutName1_KzMfIgG1_RL4.txt
##               5) $OutName1_KzMfIgG1_RL5.txt
#
## IgG2a
#
#InFile=$OutName1"_KzMfIgG2a.txt"
#echo $InFile
#OutName=$OutName1"_KzMfIgG2a"
#echo $OutName
#
#perl 02_KzMfRLTagFilterLoopArgv_150714.pl ../$InFile ../$OutName
#
#echo -e '\a'    # Beep
#echo -e '\a'    # Beep
#
##   OutPuts are 1) $OutName1_KzMfIgG2a_RL1.txt
##               2) $OutName1_KzMfIgG2a_RL2.txt
##               3) $OutName1_KzMfIgG2a_RL3.txt
##               4) $OutName1_KzMfIgG2a_RL4.txt
##               5) $OutName1_KzMfIgG2a_RL5.txt
#
#################  Step(2) Done  ####################################
#
#echo -e "\n(2) RLTagFilter_Done: " >> ../$BigLogName
#date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
#
#echo -e '\a'    # Beep
#echo -e '\a'    # Beep


##  ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]











### 170809  UniHomTtl >> Omitted !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1

###  $$(3)  #####
#
#echo -e "\n(3) Total_Uni_Homo_Rds_Started: " >> ../$BigLogName
#date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
#
#
###　(3) Total_Uni_Homo_Rds  #####  (Ig(3) x RL(4t5))を順次UniRdsにかける　　##############
#
##for i in M G1 G2a
#for i in M G1 G2a G3 A
#do
#echo $i
#
##for j in 1 2 3 4            ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
##do
##echo $j
#
#
### InPutFile:
##InFile=$OutName1"_KzMfIg"$i"_RL"$j".txt"
#InFile=$OutName1"_KzMfIg"$i".txt"           ## WithOut RL-Tag
#echo $InFile
#
### OutPutFileName_TtlUniHom
##OutName=$OutName1"_KzMfIg"$i"_RL"$j"
#OutName=$OutName1"_KzMfIg"$i          ## WithOut RL-Tag
#echo $OutName
#
#
###  IgBlastOut to ExcelFile
#perl ~/KzPipeLines/03_KzMfUniRdsVer6_If1Eq2Hom_1.pl ./$InFile ./$OutName
#
#
###
##   OutPuts are 1) $OutName1"_KzMfIg"$i"_RL"$j"_TtlRds.txt"
##                       ...
##               2) $OutName1"_KzMfIg"$i"_RL"$j"_UniRds.txt"
##                       ...
##               3) $OutName1"_KzMfIg"$i"_RL"$j"_HomRds.txt"
##                       ...
##               4) $OutName1"_KzMfIg"$i"_RL"$j"_HomRds.txt"
##                       ...
##               5) $OutName1"_KzMfIg"$i"_RL"$j"_HomRds.txt"
##                       ...
##
##
###  #######
#
#echo -e '\a'        #Beep
#
##done        #for j
#done        #for i
#
#
#################  Step(3) Done  ####################################
#
#echo -e "\n(3) Total_Uni_Homo_Rds_Done: " >> ../$BigLogName
#date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
#
#echo -e '\a'    # Beep
#echo -e '\a'    # Beep
#














##  $$(4)  #####

echo -e "\n(4) IgBlast_Started: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

##　(4) IgBlast  #####  (Ig(3) x RL(4t5))を順次IgBlastにかける　　##############

#for i in M G1 G2a
#for i in M G1 G2a G3 A
for i in M
do
echo $i


#for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
#do
#echo $j


### 170809  Ttl_Only
#for k in Ttl Uni Hom
#do
#echo $k




## -queryにInPutFile:    # 上で：   OutPuts are 1) $OutName1_KzMfIgM.txt
#InFile=$OutName1"_KzMfIg"$i"_RL"$j"_"$k"Rds.txt"
InFile=$OutName1"_KzMfIg"$i".txt"           ## WithOut RL-Tag
echo $InFile


## OutPutFileName_Blast
#OutName=$OutName1"_KzMfIg"$i"_RL"$j"_"$k"Rds_IgBlast.txt"
#OutName=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlast.txt"          ## WithOut RL-Tag
OutName=$OutName1"_KzMfIg"$i"_TtlRds_IgBlast.txt"          ## WithOut RL-Tag
echo $OutName


## OutPutFileName_Blast>Excel
#OutName2=$OutName1"_KzMfIg"$i"_RL"$j"_"$k"Rds_IgBlastExcel.txt"
#OutName2=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastExcel.txt"        ## WithOut RL-Tag
OutName2=$OutName1"_KzMfIg"$i"_TtlRds_IgBlastExcel.txt"        ## WithOut RL-Tag
echo $OutName2




##  IgBlast !!!!!!!!
igblastn -germline_db_V $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghV_NtdDb.txt -germline_db_J $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghJ_NtdDb.txt -germline_db_D $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghD_NtdDb.txt -organism mouse -domain_system imgt -query ./$InFile -auxiliary_data $IGDATA/optional_file/mouse_gl.aux -show_translation -outfmt 7 >> ./$OutName



##  IgBlastOut to ExcelFile
perl ~/KzPipeLines/04_KzIgBlast_N_ProductiveRandom_OutToExcel_ArgvRun_150730.pl ./$OutName ./$OutName2
#perl 04d_KzIgBlast_N_ProductiveRandom_ShmMtEq3_OutToExcel_ArgvRun_150820.pl ../$OutName ../$OutName2       ## Shm

##
#   OutPuts are 1) $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastExcel.txt"
##

echo -e '\a'        #Beep



#done                    #for k
#done                    #for j
done                    #for i


##
################  Step(4) Done  #############################################################

echo -e "\n(4) IgBlast_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep

















##  $$(5)  #####

echo -e "\n(5) After_IgBlast_1_Started: " >> ../$BigLogName
date >> ../$BigLogName


##　(5) After_IgBlast_1  #####  Perl: IgBlast_productive > V,D,J_BestMatch_List > RmCmLn まで　　##############

#for i in M G1 G2a
#for i in M G1 G2a G3 A
for i in M
do
echo $i


#for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
#do
#echo $j


#for k in Ttl Uni Hom
for k in Ttl                # 170809
do
echo $k



## InPutFile:
#InFile=$OutName1"_KzMfIg"$i"_RL"$j"_"$k"Rds_IgBlastExcel.txt"
InFile=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastExcel.txt"          ## WithOut RL-Tag
echo $InFile


## OutPutFileName_Blast
#OutName=$OutName1"_KzMfIg"$i"_RL"$j"_"$k"Rds_IgBlastProd"
OutName=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastProd"              ## WithOut RL-Tag
echo $OutName


##  Perl::05_KzPipeLineAfterIgBlastPerl_Kz150714.pl

perl ~/KzPipeLines/05_KzPipeLineAfterIgBlastPerl_Kz150714.pl ./$InFile ./$OutName

##
# $outputs are $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastProd_VdjSortRmCmLn.fna.txt"





echo -e '\a'        #Beep



done                    #for k
#done                    #for j
done                    #for i



################  Step(5) Done  #############################################################

echo -e "\n(5) After_IgBlast_1  #####  Perl: IgBlast_productive > V,D,J_BestMatch_List > RmCmLn まで_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

echo -e '\a'    # Beep
echo -e '\a'    # Beep
















##  $$(6)  #####

echo -e "\n(6) After_IgBlast_2_Started: " >> ../$BigLogName
date >> ../$BigLogName


##　(6) After_IgBlast_2  #####  R: RmCmLn > VDJ_Matrix > Rgl まで　　##############

#cd ../



#for i in M G1 G2a
#for i in M G1 G2a G3 A
for i in M
do
echo $i


#for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
#do
#echo $j


#for k in Ttl Uni Hom
for k in Ttl            # 170809
do
echo $k




## InPutFile:
#InFile=$OutName1"_KzMfIg"$i"_RL"$j"_"$k"Rds_IgBlastProd_VdjSortRmCmLn.fna.txt"
InFile=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastProd_VdjSortRmCmLn.fna.txt"             ## WithOut RL-Tag
echo $InFile


## OutPutFileNameSuffices_R
#OutName=$OutName1"_KzMfIg"$i"_RL"$j"_"$k"Rds_IgBlastProd_VdjSortRmCmLn.fna"
OutName=$OutName1"_KzMfIg"$i"_"$k"Rds_IgBlastProd_VdjSortRmCmLn.fna"         ## WithOut RL-Tag
echo $OutName


##  R_Prescription

r --vanilla --slave --args $InFile $OutName << EOF  ##################

args <- commandArgs(trailingOnly = T) # コマンドライン引数を読み込む

library(beepr)
beep(2)


if(length(args) != 2) { # 引数の数をチェックする。引数が2つでない場合は...
write("Error: commandline arguments for <infile> <outfile> are required", stderr())
# エラーメッセージを表示して...
q() # 終了する。
}



# printArgs.R
#args <- commandArgs(trailingOnly = T)
#print("---------------When trailingOnly equals to True:-------")
#print(args)
#args <- commandArgs(trailingOnly = F)
#print("---------------When trailingOnly equals to False:------")
#print(args)

print (args[1])
print (args[2])

infile <- args[1] # 1番目の引数を入力ファイル名として代入する
print(infile)
outfile <- args[2] # 2番目の引数を出力ファイル名として代入する。
print(outfile)

Data1 <- read.table(infile)
DataName <- outfile

#source("06_Kz150714R_CompletePipeLine_Vdj3R_Rgl.R")
#source("06_Kz160223R_CompletePipeLine_Vdj3R_Rgl_OmitScene3d_PngRes.R")
#source("06_Kz160225R_CompletePipeLine_Vdj3R_Rgl_OmitScene3d_PngRes2.R")
source("06_Kz160312R_CompletePipeLine_Vdj3R_Rgl_WndRctZm.R")



EOF
#############################################

##
# $outputs are $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastProd_VdjSortRmCmLn.fna.txt"






echo -e '\a'        #Beep


done                    #for k
#done                    #for j
done                    #for i

################  Step(5) Done  #############################################################




### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#cd ./01_CmpltPLine_Cmplt2_WoRLTag_Scribe151016      #  一つ下の、Program_Dirに戻る！  ##!!!!!!!!!!!!!!!!!!!!!!!  ########  !!!!!!!!!!!!!!!!!!!  ##
###!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



echo -e "\n(6) After_IgBlast_2  #####  R: RmCmLn > VDJ_Matrix > Rgl まで_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
echo $InPutFileName >> ../$BigLogName
echo -e "\n Done: " >> ../$BigLogName



echo -e '\a'        #Beep




#done        # Nv_InPut単位の終わり> つぎのNvInPutへ


##  ALL DONE!!!!!!!!!!!!!  #####

echo -e "\n All_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

echo -e '\a'        #Beep
echo -e '\a'        #Beep


### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#cd ../../      #  ２つ上の、BigLogの有るDirにもどる
###!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

## !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
cd ../      #  一つ上の、.sh_Dirに戻る！  ##!!!!!!!!!!!!!!!!!!!!!!!  ########  !!!!!!!!!!!!!!!!!!!  ##
##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


## Done_Loop #################################


#done        #for Para_1

### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#cd ../      #  一つ上の、.sh_Dirに戻る！  ##!!!!!!!!!!!!!!!!!!!!!!!  ########  !!!!!!!!!!!!!!!!!!!  ##
###!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


#done        #for Para_2
#done        #for Para_3
done        #for Para_4

##################

echo -e '\a'        #Beep
echo -e '\a'        #Beep
echo -e '\a'        #Beep

## All Done ######################################

