#!/usr/bin/perl -w

###########################################################
#
#   KzIgBlastExcelToMfasta_Argv_160308.pl
#
##  Run:  ##################################################
#
#   perl KzIgBlastExcelToMfasta_Argv_160308.pl InPutFile. OutPutFile
#
####################################################
#
#
#       The derivative of KzMFImgtTabF
#
#
##############
#
#
#       Ver1    160308
#
#######################################################################################

################################################################
#
######################################################

use strict;
use warnings;

my ($output);
my ($output1);
my ($prod);
my ($seqid);
my ($hit);

my ($Sequence_ID, $V_GeneTop, $J_GeneTop, $Chain_type, $Stop_codon, $VJ_frame, $Productive, $Strand);


#print " Output file name? ", "\n";
#chomp ( $output = <STDIN>  );

chomp ( $output = $ARGV[1] );
## OutPutFileを開く
open ( SUBFILE1, ">>$output" ) or die "Cannnot open SubSeq.fa", "\n";


## InPutFileを開く
open(MOM0,"$ARGV[0]"); 			# SearchList.txtファイルMOM0をopenする


## InPutFile処理
$hit=0;

while (<MOM0>)  {
 	chomp ($_);
    	($Sequence_ID, $V_GeneTop, $J_GeneTop, $Chain_type, $Stop_codon, $VJ_frame, $Productive, $Strand) = split(/\t/,$_);
    

		$hit++;
    
		$seqid=$Sequence_ID;
		print SUBFILE1 ">",$seqid,"\n";
		print ">",$seqid,"\n";
		print SUBFILE1 $V_GeneTop,"\t", $J_GeneTop,"\t", $Chain_type,"\t", $Stop_codon,"\t", $VJ_frame,"\t", $Productive,"\t", $Strand,"\n";
		print $V_GeneTop,"\t", $J_GeneTop,"\t", $Chain_type,"\t", $Stop_codon,"\t", $VJ_frame,"\t", $Productive,"\t", $Strand,"\n";

}

close (MOM0);
close (SUBFILE1);

$hit = $hit - 1;


print "\n", " -- Done -- ", " [ ",$hit," Sequences wrote ]","\n";
#print "\007";
#print "\007";
print "\007";

# End


	
