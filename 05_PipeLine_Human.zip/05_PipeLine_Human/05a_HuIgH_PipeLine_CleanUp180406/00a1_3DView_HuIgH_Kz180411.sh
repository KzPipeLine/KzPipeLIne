#!/bin/bash

#############################################
##
##  00a1_3DView_HuIgH_Kz180411.sh
##
####  Run:  ###############
##
##  $ . 00a1_3DView_HuIgH_Kz180411.sh
##
########################################
##
##  Ver1:   180312
#
#
##
####  Steps:  #################################
##
##  (0) Starting Data: SRR1585248_Polished_TrmQflRcp_1K.fna
##
##  (1) 01_KzMfHuIgHCmgadeNtdVer1_Kz180312.pl
##
##  [(2) RLTagFilter ]
##
##  [(3) UniRds_TtlUniHom]
##
##  (4) IgBlastN_ProdRand_(ShmMtEq2)
##
##  (5) After_IgBlast_1  #####  Perl: IgBlast_productive > V,D,J_BestMatch_List > RmCmLn まで
##
##  (6) After_IgBlast_2  #####  R: RmCmLn > VDJ_Matrix > Rgl まで
##
##
#######################################################################################


#!/bin/bash


## Start_line...........................

## Do_Loops ###### >> Done_Loops @ bottom below ##################

# (0) BM or T2
#for Para_4 in boostD7    ## <<<<<<<<<<<<<<<< InPut !!!!!!!!!!!!!!!!!!!!!!!!!!!!
for Para_4 in Test180312_Polished_TrmQflRcp_20k     ## <<<<<<<<<<<<<<<< InPut !!!!!!!!!!!!!!!!!!!!!!!!!!!!
do
echo -e  "Para_4::"
echo $Para_4



## [0] Name of the Folder #####################
FolderName=$Para_4
echo -e  "FolderName::"
echo -e $FolderName
cd ./$FolderName            # Folderに入る
##########################################################

##################
## InPutNames!!!!!!!!!!!!!!!!!!!!!!
## KO
#[1] Name of the Project
ProjectName=$FolderName		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Check !!
echo -e  "ProjectName::"
echo -e $ProjectName

#[2] Name of 1st InPutFile
#InPutFile_1=$FolderName".fastq_Polished_RenTrmQflRcp.fna"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Check !!
InPutFile_1=$Para_4".fna"		## <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Check !!
echo -e  "InPutFile_1::"
echo -e $InPutFile_1



############################
## Making2ndNames!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#[1] BigLogName
BigLogName="00a_"$ProjectName"_BigLog.txt"
echo -e  "BigLogName::"
echo -e $BigLogName





##################################
## Here Starts!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

echo -e "\n## "$ProjectName"_Started........." | tee -a  ../$BigLogName
date | tee -a  ../$BigLogName







##  OutName1を与える  #########
OutName1=$Para_4     ##  <<<<<<<<  !!!!!!!!!!!  (2) OutName1を与える <<<　自動でOK  <<<<<<<<<<<<<<<<<<<<<<
echo -e  "OutName1::"
echo $OutName1








##  $$(1)  #####

echo -e "\n(1) IgCmggNtd_Started: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

## (1) IgCmggNtd  #####　Ampliconの中のIgCmggNtd配列を持つものを抽出して、IgM,IgG1,IgG2cの3グループに分類
## (1) IgCmggNtd  #####　Ampliconの中のIgCmggNtd配列を持つものを抽出して、IgM,IgG1,IgG2c,IgG3,IgAの3グループに分類

OutName=$OutName1
echo -e  "OutName::"
echo $OutName


perl ./01_KzMfHuIgHCmgadeNtdVer1_Kz180312.pl ./$InPutFile_1 ./$OutName     ##  <<<<<< !!!!!!!!  (3) Data_Fileを指定 <<<<<<<<<<

#   OutPuts are 1) $OutName1_KzMfHuIgM.txt
#               2) $OutName1_KzMfHuIgG1234.txt.txt
#               3) $OutName1_KzMfHuIgA12.txt
#               4) $OutName1_KzMfHuIgD.txt
#               5) $OutName1_KzMfHuIgE.txt

################  Step(1) Done  ########################

echo -e "\n(1) IgCmggNtd_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
echo -e '\a'    # Beep
echo -e '\a'    # Beep




##  $$(4)  #####

echo -e "\n(4) IgBlast_Started: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

##　(4) IgBlast  #####  (Ig(3) x RL(4t5))を順次IgBlastにかける　　##############

#for i in M G1 G2a
#for i in M G1234 A12 D E
for i in M G1234 A12
do
echo $i


#for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
#do
#echo $j


### 170809  Ttl_Only
#for k in Ttl Uni Hom
#do
#echo $k




## -queryにInPutFile:    # 上で：   OutPuts are 1) $OutName1_KzMfIgM.txt
InFile=$OutName1"_KzMfHuIg"$i".txt"           ## WithOut RL-Tag
echo $InFile


## OutPutFileName_Blast
OutName=$OutName1"_KzMfHuIg"$i"_TtlRds_IgBlast.txt"          ## WithOut RL-Tag
echo $OutName


## OutPutFileName_Blast>Excel
OutName2=$OutName1"_KzMfHuIg"$i"_TtlRds_IgBlastExcel.txt"        ## WithOut RL-Tag
echo $OutName2




##  IgBlast !!!!!!!!
# Mouse
#igblastn -germline_db_V $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghV_NtdDb.txt -germline_db_J $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghJ_NtdDb.txt -germline_db_D $IGDATA/ImtgMouseIg_ntd_Kz150601/Kz150601ImtgMouseIghD_NtdDb.txt -organism mouse -domain_system imgt -query ./$InFile -auxiliary_data $IGDATA/optional_file/mouse_gl.aux -show_translation -outfmt 7 >> ./$OutName

# Human
igblastn -germline_db_V $IGDATA/ImtgHumanIg_ntd_Kz150601/Kz150601ImtgHumanIghV_NtdDb.txt -germline_db_J $IGDATA/ImtgHumanIg_ntd_Kz150601/Kz150601ImtgHumanIghJ_NtdDb.txt -germline_db_D $IGDATA/ImtgHumanIg_ntd_Kz150601/Kz150601ImtgHumanIghD_NtdDb.txt -organism human -domain_system imgt -query ./$InFile -auxiliary_data $IGDATA/optional_file/Human_gl.aux -show_translation -outfmt 7 >> ./$OutName




##  IgBlastOut to ExcelFile
perl ./04_KzIgBlast_N_ProductiveRandom_OutToExcel_ArgvRun_180312.pl ./$OutName ./$OutName2       ## Human

##
#   OutPuts are 1) $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastExcel.txt"
##

echo -e '\a'        #Beep



#done                    #for k
#done                    #for j
done                    #for i


##
################  Step(4) Done  #############################################################

echo -e "\n(4) IgBlast_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

#echo -e '\a'    # Beep
echo -e '\a'    # Beep




##  $$(5)  #####

echo -e "\n(5) After_IgBlast_1_Started: " >> ../$BigLogName
date >> ../$BigLogName


##　(5) After_IgBlast_1  #####  Perl: IgBlast_productive > V,D,J_BestMatch_List > RmCmLn まで　　##############

#for i in M G1 G2a
#for i in M G1 G2a G3 A
#for i in M G1234 A12 D E
for i in M G1234 A12
do
echo $i


#for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
#do
#echo $j


#for k in Ttl Uni Hom
for k in Ttl                # 170809
do
echo $k



## InPutFile:
InFile=$OutName1"_KzMfHuIg"$i"_"$k"Rds_IgBlastExcel.txt"          ## WithOut RL-Tag
echo $InFile


## OutPutFileName_Blast
OutName=$OutName1"_KzMfHuIg"$i"_"$k"Rds_IgBlastProd"              ## WithOut RL-Tag
echo $OutName


##  Perl::05_KzPipeLineAfterIgBlastPerl_Kz150714.pl
perl ./05_KzHuPipeLineAfterIgBlastPerl_Kz180312.pl ./$InFile ./$OutName       ## Human

##
# $outputs are $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastProd_VdjSortRmCmLn.fna.txt"





echo -e '\a'        #Beep



done                    #for k
#done                    #for j
done                    #for i



################  Step(5) Done  #############################################################

echo -e "\n(5) After_IgBlast_1  #####  Perl: IgBlast_productive > V,D,J_BestMatch_List > RmCmLn まで_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

echo -e '\a'    # Beep
echo -e '\a'    # Beep





##  $$(6)  #####

echo -e "\n(6) After_IgBlast_2_Started: " >> ../$BigLogName
date >> ../$BigLogName


##　(6) After_IgBlast_2  #####  R: RmCmLn > VDJ_Matrix > Rgl まで　　##############

#cd ../



#for i in M G1 G2a
#for i in M G1 G2a G3 A
#for i in M G1234 A12 D E
for i in M G1234 A12
do
echo $i


#for j in 1 2 3 4   ##  <<<<<<<<<<<<<<<<<  !!!!!!!!!!!!!!!!  RL = JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ  !!!!!!!!!!!!!!!!!!
#do
#echo $j


#for k in Ttl Uni Hom
for k in Ttl            # 170809
do
echo $k




## InPutFile:
InFile=$OutName1"_KzMfHuIg"$i"_"$k"Rds_IgBlastProd_VdjSortRmCmLn.fna.txt"             ## WithOut RL-Tag
echo $InFile


## OutPutFileNameSuffices_R
OutName=$OutName1"_KzMfHuIg"$i"_"$k"Rds_IgBlastProd_VdjSortRmCmLn.fna"         ## WithOut RL-Tag
echo $OutName


##  R_Prescription

r --vanilla --slave --args $InFile $OutName << EOF  ##################

args <- commandArgs(trailingOnly = T) # コマンドライン引数を読み込む

library(beepr)
beep(2)


if(length(args) != 2) { # 引数の数をチェックする。引数が2つでない場合は...
write("Error: commandline arguments for <infile> <outfile> are required", stderr())
# エラーメッセージを表示して...
q() # 終了する。
}


print (args[1])
print (args[2])

infile <- args[1] # 1番目の引数を入力ファイル名として代入する
print(infile)
outfile <- args[2] # 2番目の引数を出力ファイル名として代入する。
print(outfile)

Data1 <- read.table(infile)
DataName <- outfile


# Human
source("06_Kz180312R_HuCompletePipeLine_Vdj3R_Rgl_WndRctZm.R")



EOF
#############################################

##
# $outputs are $OutName1"_KzMfIg"$i"_RL"$j"_IgBlastProd_VdjSortRmCmLn.fna.txt"






echo -e '\a'        #Beep


done                    #for k
#done                    #for j
done                    #for i

################  Step(5) Done  #############################################################


echo -e "\n(6) After_IgBlast_2  #####  R: RmCmLn > VDJ_Matrix > Rgl まで_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み
echo $InPutFileName >> ../$BigLogName
echo -e "\n Done: " >> ../$BigLogName



echo -e '\a'        #Beep



##  ALL DONE!!!!!!!!!!!!!  #####

echo -e "\n All_Done: " >> ../$BigLogName
date >> ../$BigLogName                           # DoneTimeのLog_fileへの書き込み

echo -e '\a'        #Beep
echo -e '\a'        #Beep


## !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
cd ../      #  一つ上の、.sh_Dirに戻る！  ##!!!!!!!!!!!!!!!!!!!!!!!  ########  !!!!!!!!!!!!!!!!!!!  ##
##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


## Done_Loop #################################


#done        #for Para_1

### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#cd ../      #  一つ上の、.sh_Dirに戻る！  ##!!!!!!!!!!!!!!!!!!!!!!!  ########  !!!!!!!!!!!!!!!!!!!  ##
###!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


#done        #for Para_2
#done        #for Para_3
done        #for Para_4

##################

echo -e '\a'        #Beep
echo -e '\a'        #Beep
echo -e '\a'        #Beep

## All Done ######################################

